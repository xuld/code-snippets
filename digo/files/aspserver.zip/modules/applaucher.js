/**
 * 用于启动 apps 的入口模块
 * @author xuld@vip.qq.com
 */

exports.init = function (application) {
	application.apps = application.apps || {};
	application.loadModules(application.apps);
};

exports.processRequest = function  (context) {
	var path = context.request.path;
	var colonIndex = path.lastIndexOf(':');
	if(colonIndex < 0){
		return false;
	}
	
	var appName = path.substr(colonIndex + 1);
	
	var app = context.applicationInstance.apps[appName];
	if(!app) {
		return false;
	}

	return app.processRequest(context, path.substr(0, colonIndex)) !== false;
};