﻿# AspServer

一个即拿即用的 NODE 服务器框架，帮助快速搭建一个服务器，并自动拥有目录浏览等功能。

## 基本用法

    var AspServer = require('aspserver');
    
    var server = new AspServer({
        port: 8080,
        physicalPath: "./"
    });

    server.start();