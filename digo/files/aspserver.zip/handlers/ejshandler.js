

var ejs = require('ejs');

exports.processContent = function(content, context){
    context.response.contentEncoding = 'UTF-8';
    context.response.contentType = 'text/html; charset=UTF-8';
	try{
		content = ejs.render(content, context.applicationInstance.ejs);
	}catch(e){
		context.reportError(500, e);
		return;
	}
	context.response.write(content);
	context.response.end();
};

exports.processRequest = require('./common').processRequest;


