﻿// This file is expected to be loaded by test2.js
console.log('test3.js loaded');