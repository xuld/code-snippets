
var ModuleBuilder = require('../modulebuilder');


ModuleBuilder.build({

	inputEncoding: 'utf-8',
	
	outputEncoding: 'utf-8',
	
	inputs: ['sampleproject/b.js'],

	outputJs: 'build/output.js',
	outputCss: 'build/output.css',

	minify: true

});