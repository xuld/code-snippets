
// #import ./test1.css
// #include ./test1.js

// #import ./test2.css
// #include ./test2.js

// should be loaded ONLY ONCE
// #include ./test2.js