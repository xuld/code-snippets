﻿// This file is expected to be loaded by index.js
console.log('test2.js loaded');

// #include ./test3.js