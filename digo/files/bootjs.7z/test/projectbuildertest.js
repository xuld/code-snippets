
var ProjectBuilder = require('../projectbuilder');


ProjectBuilder.build({

	from: 'sampleproject/',

	to: 'dest/',
	
	redirects: [
		
		{
			from: /aa/,
			to: '$1',
			continueRedirect: true,
		},
	
		{
			from: /bb/,
			to: '$1'
		},
	
		{
			from: /bb/,
			to: null,
		},
	
	],
	
	fileTypes: {
		
		'.js': {
			minify: true,
			resolveRequireJs: true,
			resolveBootJs: true
		},
		
		'.css': {
			minify: true,
			resolveBootJs: true
		},

		'.html': {
			resolveInclude: true,
		},
		
		'.tmp': {
			ignore: true,
		},
		
		'.ai': {
			ignore: true,
		},
		
		'.psd': {
			ignore: true,
		}
	
	}

});