﻿// This file is expected to be loaded by index.js
console.log('test1.js loaded');