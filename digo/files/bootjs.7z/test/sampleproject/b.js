// #require ./a.css
// #require ./a.js
console.log('b.js' )