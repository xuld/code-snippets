﻿var tpack = require("tpack");

tpack.autoClean = false;
tpack.sourceMap = true;

tpack.srcPath = "src";
tpack.destPath = "lib";

tpack.src("*.ts").ignore("*.d.ts").pipe(tpack.plugin("tpack-typescript"));
