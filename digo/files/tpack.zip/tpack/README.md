TPack
========================================================
TPack 是一个 NodeJS 开发的基于规则的项目构建工具。
通过插件，TPack 可以提供代码打包、压缩、合并、优化等功能。

下载安装
-------------------------------
1. 安装 NodeJS 和 npm。具体见 [NodeJS 官网](https://nodejs.org)。
2. 使用 npm 安装 TPack:

    > npm install tpack -g

> 安装完成后执行 `tpack -v`，如果输出了版本号，说明安装正确。

3. 下载 TPack 常用插件：
     
    > npm install -g tpack-uglify-js tpack-clean-css tpack-autoprefixer tpack-modular tpack-concat tpack-babel tpack-coffee-script tpack-typescript tpack-less tpack-node-sass tpack-node-markdown

> 更多插件见 [插件列表](https://github.com/tpack/tpack/wiki/插件列表)。

首次使用
-------------------------------

### 1. 在项目根目录新建 `tpack.config.js` 文件：

    var tpack = require("tpack");
    
    // 定义 .txt 文件的处理方式。
    tpack.src("*.txt")
        .pipe(function(file){  
            file.content += "哈哈";
        })
        .dest("$1.out");

> 提示：可以使用 `tpack --init` 命令自动生成 `tpack.config.js`。
    
### 2. 发布项目

执行 `tpack` 发布项目:

	> tpack
    [10:00:00]Start Building 'D:\www' -> 'D:\www\_out' ...
    [10:00:02]Building Success!

根据如上配置文件，可以发现当前文件夹所有文件都已复制到 _dest，并且其中 .txt 文件末尾都会追加上“哈哈”两个字。

### 3. 实时编译(增量发布)

执行 `tpack -w` 即可监听所有 *.txt 文件并在文件保存后重新生成。

    > tpack -w
    [10:00:00]Start Watching 'D:\www' ...

### 4. 开发服务器

执行 `tpack --server` 打开开发服务器：

    > tpack --server

在服务器打开 http://localhost:8080/a.txt ，可以查看已处理过的代码。

### 5. 任务

TPack 可以定义多个任务，并根据需求执行不同的任务。在 `tpack.config.js` 中使用如下代码可以定义一个任务。

    tpack.task("hello", function(options){
        console.log(options.name);
    });

然后执行以下命令调用任务：

    > tpack hello -name world

在控制台将会到输出了 `world`。

> 提示：当直接执行 `tpack` 时，相当于执行了名为 `default` 的任务。

优势
-------------------------------
- **更简洁的配置**：只需指定文件如何处理，即可快速发布项目。
- **执行效率高**：只需全局安装一遍，随时使用。
- **记录文件依赖**：当一个文件修改时，相关的文件会自动同步。如 html 引用了 a.css，当 a.css 被重命名为 a_20050801.css 时，html 内的引用也会自动更新。

常见需求
-------------------------------
- [压缩 js/css/html](https://github.com/tpack/tpack/wiki/压缩)
- [编译 .less/.sass/.coffee/.jsx/.ts/.md 等](https://github.com/tpack/tpack/wiki/编译)
- [优化：jslint/postcss](https://github.com/tpack/tpack/wiki/优化)
- [打包合并：require 打包/html 内联/时间戳](https://github.com/tpack/tpack/wiki/模块化)

`tpack.config.js` 模板
-------------------------------

    var tpack = require("tpack");
    
    // 常用忽略文件。
    tpack.loadIgnore(".gitignore");
    tpack.ignore(".*", "_*", "$*", "*~", "node_modules");
    
    // 常规开发时，执行 tpack -w。
    tpack.task("default", function () {
    
        // 输出文件夹。
        tpack.destPath = "_out";
    
        // 编译 CSS。
        tpack.src("*.scss", "*.sass").pipe(tpack.plugin("tpack-node-sass"));
        tpack.src("*.less").pipe(tpack.plugin("tpack-less"));
        tpack.src("*.css").pipe(tpack.plugin("tpack-autoprefixer"));
    
        // 编译 JS。
        tpack.src("*.coffee").pipe(tpack.plugin("tpack-coffee-script"));
        tpack.src("*.ts", "*.tsx").pipe(tpack.plugin("tpack-typescript"));
        tpack.src("*.es", "*.es6", "*.jsx").pipe(tpack.plugin("tpack-babel"));
    
        // 模块打包合并。
        tpack.src("*").pipe(tpack.plugin("tpack-modular"));
    });
    
    // 发布上线时，执行 tpack p。
    tpack.task("publish, p", function () {
        tpack.task("default");
    
        // 输出文件夹。
        tpack.destPath = "_upload";
    
        // 压缩。
        tpack.src("*.css").pipe(tpack.plugin('tpack-clean-css'));
        tpack.src("*.js").pipe(tpack.plugin('tpack-uglify-js'));
        tpack.src("*.html", "*.htm").pipe(tpack.plugin('tpack-html-minifier'));
    });

文档
-------------------------------
要查看入门教程、API 文档、插件开发指南，请进入：[文档页面](文档)

支持我们
-------------------------------
- 欢迎通过[推送请求](https://help.github.com/articles/using-pull-requests)帮助我们改进产品质量。
- 如果您有任何项目需求和建议，欢迎[发送反馈](https://github.com/tpack/tpack/issues/new)。
