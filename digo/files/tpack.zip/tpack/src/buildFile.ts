﻿/**
 * @fileOverview 生成文件。
 */

import * as Path from "path";
import * as FS from "fs";
import {createHash} from "crypto";

import {RawSourceMap, SourceMapConsumer, SourceMapGenerator} from "source-map";
import * as IO from "tutils/node/io";

import {Builder, BuildAction, Filter, compileFilters, LogLevel, relative, containsDir, padZero} from "./builder";
import {BuildRule, GroupBuildRule} from "./buildRule";

/**
 * 表示一个生成文件。
 * @remark
 * 一个生成文件可以是一个物理文件或虚拟文件。
 */
export class BuildFile {

    // #region 文件属性

    /**
     * 获取当前文件所属的生成器。
     */
    builder: Builder;

    /**
     * 判断当前文件是否是生成的文件。
     */
    isGenerated: boolean;

    /**
     * 判断当前文件是否实际存在。
     */
    get exists() { return !this.isGenerated && IO.existsFile(this.srcPath); }

    /**
     * 判断当前文件是否来自外部项目。
     */
    get isImported() { return containsDir(this.builder.srcPath, this.srcPath); }

    /**
     * 初始化新的文件。
     * @param builder 当前文件所属的生成器。
     * @param name 当前文件的初始名称。
     * @param data 当前文件的初始内容。
     */
    constructor(builder: Builder, name: string, data?: string | Buffer) {
        this.builder = builder;
        this.destName = this.srcName = name;
        if (data != null) {
            this.isGenerated = true;
            if (typeof data === "string") {
                this._srcContent = data;
            } else {
                this._srcBuffer = data;
            }
        }
    }

    /**
     * 存储读写当前文件使用的编码。
     */
    private _encoding: string;

    /**
     * 获取读写当前文件使用的编码。
     */
    get encoding() { return this._encoding || this.builder.encoding; }

    /**
     * 设置读写当前文件使用的编码。
     */
    set encoding(value) { this._encoding = value; }

    /**
     * 获取当前文件的路径。
     */
    valueOf() { return this.srcPath; }

    /**
     * 获取当前文件的字符串形式。
     */
    toString() { return this.content; }

    // #endregion

    // #region 文件路径

    /**
     * 获取当前文件的源名称。
     */
    srcName: string;

    /**
     * 获取当前文件的源路径。
     */
    get srcPath() { return this.srcName ? Path.resolve(this.builder.srcPath, this.srcName) : null; }

    /**
     * 获取当前文件的目标名称。
     */
    destName: string;

    /**
     * 获取当前文件的目标路径。
     */
    get destPath() { return this.destName ? Path.resolve(this.builder.destPath, this.destName) : null; }

    /**
     * 获取当前文件的显示名。
     */
    get displayName() {
        return this.isGenerated ?
            (this.builder.dict["<Generated>"] || "<Generated>") + ((this.builder.fullPath ? this.destPath : this.destName) || "") :
            (this.builder.fullPath ? this.srcPath : this.srcName);
    }

    /**
     * 获取当前文件的最终名称。
     */
    get name() { return this.destName; }

    /**
     * 设置当前文件的最终名称。
     */
    set name(value) { this.destName = value; this._saveStatus = 0; }

    /**
     * 获取当前文件的最终路径。
     */
    get path() { return this.destPath; }

    /**
     * 设置当前文件的最终保存路径。
     */
    set path(value) { this.name = this.builder.toName(value); }

    /**
     * 测试当前文件是否匹配指定筛选器。
     * @param filter 要匹配的筛选器。可以使用通配符、正则表达式、自定义函数或以上组合的列表。
     * @returns 如果匹配则返回 @true，否则返回 @false。
     */
    match(filter: Filter): boolean;

    /**
     * 测试当前文件是否匹配指定筛选器，并替换为新名称。
     * @param filter 要匹配的筛选器。可以使用通配符、正则表达式、自定义函数或以上组合的列表。
     * @param target 要替换的目标名称。其中 $0, $1... 会被替换为原通配符匹配的内容。
     * @returns 如果匹配则返回 @target，其中 $0, $1... 会被替换为原通配符匹配的内容，否则返回 @null。
     */
    match(filter: Filter, target: string): string;

    /**
     * 测试当前文件是否匹配指定筛选器，并替换为新名称。
     * @param filter 要匹配的筛选器。可以使用通配符、正则表达式、自定义函数或以上组合的列表。
     * @param target 要替换的目标名称。其中 $0, $1... 会被替换为原通配符匹配的内容。
     * @returns 如果匹配则返回 @target，其中 $0, $1... 会被替换为原通配符匹配的内容，否则返回 @null。
     */
    match(filter: Filter, target?: string) {
        return compileFilters([filter], false, this.builder.srcPath).call(this, this.name, target);
    }

    /**
     * 获取当前文件的扩展名。
     */
    get extension() { return Path.extname(this.name); }

    /**
     * 设置当前文件的扩展名。
     */
    set extension(value) { this.name = this.name.substr(0, this.name.length - this.extension.length) + value; }

    /**
     * 获取当前文件的源文件夹路径。
     */
    get srcDirPath() { return Path.dirname(this.srcPath); }

    /**
     * 获取当前文件的目标文件夹路径。
     */
    get destDirPath() { return Path.dirname(this.destPath); }

    /**
     * 解析当前文件内的地址所表示的实际地址。
     * @param url 要解析的地址。如 ../a.js?a=1
     * @returns 返回解析好的绝对地址。
     */
    resolve(url: string) {
        return /^\w+:|^\/\//.test(url) ? url : url ? Path.join(this.srcPath, "..", url) : this.srcPath;
    }

    /**
     * 获取在当前文件内引用指定地址或文件所使用的相对地址。
     * @param url 要处理的地址或文件。
     */
    relative(url: string | BuildFile) {
        return relative(Path.dirname(this.destName), typeof url === "string" ?
            this.builder.toName(url as string) :
            (url as BuildFile).destName);
    }

    // #endregion

    // #region 文件数据

    /**
     * 存储当前文件的原始文本内容。
     */
    private _srcContent: string;

    /**
     * 获取当前文件的原始文本内容。
     */
    get srcContent() {
        if (this._srcContent == null) {
            if (this._srcBuffer != null) {
                this._srcContent = this._srcBuffer.toString(this.encoding);
            } else {
                try {
                    this._srcContent = FS.readFileSync(this.srcPath, this.encoding);
                } catch (e) {
                    this._srcContent = "";
                    this.error("ReadError", e);
                }
            }

            // 删除 UTF-8 BOM 字符。
            if (this._srcContent.charCodeAt(0) === 65279) {
                this._srcContent = this._srcContent.substr(1);
            }
        }
        return this._srcContent;
    }

    /**
     * 存储当前文件的原始二进制内容。
     */
    private _srcBuffer: Buffer;

    /**
     * 获取当前文件的原始二进制内容。
     */
    get srcBuffer() {
        if (this._srcBuffer == null) {
            if (this._srcContent != null) {
                this._srcBuffer = new Buffer(this._srcContent);
            } else {
                try {
                    this._srcBuffer = FS.readFileSync(this.srcPath);
                } catch (e) {
                    this._srcBuffer = new Buffer(0);
                    this.error("ReadError", e);
                }
            }
        }
        return this._srcBuffer;
    }

    /**
     * 存储当前文件的最终文本内容。
     */
    private _destContent: string;

    /**
     * 获取当前文件的最终文本内容。
     */
    get destContent() { return this.content; }

    /**
     * 存储当前文件的最终二进制内容。
     */
    private _destBuffer: Buffer;

    /**
     * 获取当前文件的最终二进制内容。
     */
    get destBuffer() { return this.buffer; }

    /**
     * 存储当前文件的修改状态。
     * - 0：content 和 buffer 都未更新。
     * - 1：content 是最新版本。
     * - 2：buffer 是最新版本。
     * - 3：content 和 buffer 都是最新版本。
     */
    private _status: number;

    /**
     * 判断当前文件是否存在修改。
     */
    get modified() { return this._status > 0; }

    /**
     * 获取当前文件的最终保存文本内容。
     */
    get content(): string {
        if (this._status === 2) {
            this._status = 3;
            return this._destContent = this.buffer.toString(this.encoding);
        }
        if (this._destContentDelay) {
            try {
                return this._destContent = this._destContentDelay(this);
            } finally {
                delete this._destContentDelay;
            }
        }
        return this._destContent != null ? this._destContent : this.srcContent;
    }

    /**
     * 设置当前文件的最终保存文本内容。
     */
    set content(value) {
        this._destContent = value;
        this._status = 1;
        this._saveStatus = 0;
    }

    /**
     * 获取当前文件的最终保存二进制内容。
     */
    get buffer() {
        if (this._status === 1) {
            this._status = 3;
            return this._destBuffer = new Buffer(this.content);
        }
        if (this._destBufferDelay) {
            try {
                return this._destBuffer = this._destBufferDelay(this);
            } finally {
                delete this._destBufferDelay;
            }
        }
        return this._destBuffer != null ? this._destBuffer : this.srcBuffer;
    }

    /**
     * 设置当前文件的最终保存二进制内容。
     */
    set buffer(value) {
        this._destBuffer = value;
        this._status = 2;
        this._saveStatus = 0;
    }

    /**
     * 获取当前文件的二进制或文本数据。
     */
    get data() { return this._status === 1 || this._status === 3 ? this.content : this.buffer; }

    /**
     * 设置当前文件的二进制或文本数据。
     */
    set data(value) {
        if (typeof value === "string") {
            this.content = value;
        } else {
            this.buffer = value;
        }
    }

    /**
     * 存储延时设置内容的回调。
     */
    _destContentDelay: (file: BuildFile) => string;

    /**
     * 设置延时更新文本内容的回调。
     * @param getter 设置的回调。
     */
    setContentDelay(getter: (file: BuildFile) => string) {
        this._destContentDelay = getter;
        this._status = 1;
        this._saveStatus = 0;
    }

    /**
     * 存储延时设置内容的回调。
     */
    _destBufferDelay: (file: BuildFile) => Buffer;

    /**
     * 设置延时更新二进制内容的回调。
     * @param getter 设置的回调。
     */
    setBufferDelay(getter: (file: BuildFile) => Buffer) {
        this._destBufferDelay = getter;
        this._status = 2;
        this._saveStatus = 0;
    }

    // #endregion

    // #region 清理和保存

    /**
     * 存储当前文件的保存状态。
     * - 0: 未保存。
     * - 1: 已保存。
     * - 2: 已清理。
     */
    private _saveStatus: number;

    /**
     * 清理当前文件的生成文件。
     * @param deleteDir 是否同时删除空父文件夹。
     */
    clean(deleteDir?: boolean) {

        // 不重复清理。
        if (this._saveStatus === 2) return;
        this._saveStatus = 2;

        // 清理当前文件的关联文件。
        if (this.related) {
            for (let i = 0; i < this.related.length; i++) {
                this.related[i].clean(deleteDir);
            }
        }

        // 删除当前文件的源码映射表。
        if (this._sourceMapOptions && this._sourceMapOptions.enabled != null ? this._sourceMapOptions.enabled : this.builder.sourceMap) {
            let sourceMapPath = this.sourceMapPath;

            try {
                IO.deleteFile(sourceMapPath);
                // 清空父文件夹。
                if (deleteDir) {
                    IO.deleteDirIfEmpty(sourceMapPath);
                }
                this.builder.buildFileCount++;

            } catch (e) {
                this.error("DeleteError", e);
            }

        }

        // 忽略文件路径未发生改变的文件。
        // 忽略非法保存路径。
        let srcPath = this.srcPath;
        let destPath = this.destPath;
        if (srcPath.toLowerCase() === destPath.toLowerCase() || !this.builder.checkSavePath(destPath)) {
            return;
        }

        // 开始删除。
        try {
            IO.deleteFile(destPath);
            // 清空父文件夹。
            if (deleteDir) {
                IO.deleteDirIfEmpty(destPath);
            }
        } catch (e) {
            this.error("DeleteError", e);
            return;
        }

        // 清理完成。
        this.builder.buildFileCount++;
        this.builder.onFileClean(this);
    }

    /**
     * 保存当前文件。
     */
    save() {

        // 不重复保存。
        if (this._saveStatus === 1) return;
        this._saveStatus = 1;

        // 保存关联文件。
        if (this.related) {
            for (let i = 0; i < this.related.length; i++) {
                this.related[i].save();
            }
        }

        // 保存源码映射表。
        this.saveSourceMap();

        // 检验文件。
        if (this.builder.onFileValidate(this) === false) return;

        // 检验路径。
        let srcPath = this.srcPath;
        let destPath = this.destPath;
        if (srcPath.toLowerCase() === destPath.toLowerCase()) {

            // 文件路径未改变且未修改，则跳过。
            if (!this._status) return;

            // 不允许覆盖源文件。
            if (!this.builder.allowOverwrite) {
                this.error("PathError", null, "Cannot overwrite source file. Use '--overflow' to force saving.");
                return;
            }

        }

        // 不允许保存到指定路径。
        if (!this.builder.checkSavePath(destPath)) {
            this.error("PathError", null, "Cannot save files out of output folder. Use '--disable-path-check' to force saving.");
            return;
        }

        // 写入文件。
        try {
            if (this._status) {
                IO.writeFile(destPath, this._status === 1 ? this.content : this.buffer, this.encoding);
            } else {
                // TODO: 性能改进。
                IO.copyFile(srcPath, destPath);
            }
        } catch (e) {
            this.error("WriteError", e);
            return;
        }

        // 保存完成。
        this.builder.buildFileCount++;
        this.builder.onFileSave(this);
    }

    // #endregion

    // #region 生成需要

    /**
     * 存储当前文件的生成版本。
     */
    buildVersion: number;

    /**
     * 判断当前文件已经被处理。
     */
    processed: boolean;

    /**
     * 获取当前正在执行的规则。
     */
    rule: BuildRule;

    /**
     * 获取当前文件执行当前规则前的名字。
     */
    initalName: string;

    // #endregion

    // #region 包含和关联文件

    /**
     * 获取当前文件的所有引用地址。
     */
    refs: ReferenceList;

    /**
     * 添加当前文件的引用地址。
     * @param url 引用的地址。
     * @param source 设置当前引用的来源以方便调试。
     */
    ref(url: string | string[], source?: Object) {
        if (typeof url !== "string") {
            for (let i = 0; i < url.length; i++) {
                this.include(url[i], source);
            }
            return;
        }
        this.refs = this.refs || [];
        this.refs.push(url as string);

        if (source) {
            this.refs.sources = this.refs.sources || [];
            this.refs.sources[this.refs.sources.length - 1] = source;
        }
    }

    /**
     * 获取当前文件的所有包含项。
     */
    includes: ReferenceList;

    /**
     * 添加当前文件的包含项。
     * @param path 包含的路径。
     * @param source 设置当前包含的来源以方便调试。
     */
    include(path: string | string[], source?: Object) {
        if (typeof path !== "string") {
            for (let i = 0; i < path.length; i++) {
                this.include(path[i], source);
            }
            return;
        }
        this.includes = this.includes || [];
        this.includes.push(path as string);

        if (source) {
            this.includes.sources = this.includes.sources || [];
            this.includes.sources[this.includes.sources.length - 1] = source;
        }
    }

    /**
     * 获取由当前文件生成的相关文件列表。
     */
    related: BuildFile[];

    /**
     * 添加当前文件的关联文件。
     * @param file 要添加的文件。
     * @remark 关联文件可以和当前文件同步处理。
     */
    relate(file: BuildFile) {
        if (!this.related) this.related = [];
        if (this.related.indexOf(file) < 0) this.related.push(file);
    }

    // #endregion

    // #region 日志

    /**
     * 添加当前文件生成时产生的日志。
     * @param name 日志的名字。
     * @param error 原始错误对象。
     * @param message 指定日志的详细信息。
     * @param fileName 发生日志的文件名。
     * @param startLine 日志的开始行号。
     * @param startColumn 日志的开始列号。
     * @param endLine 日志的结束行号（不包含结束位置本身）。
     * @param endColumn 日志的结束列号（不包含结束位置本身）。
     * @param sourceCode 日志的源码。
     * @param level 日志的等级。
     */
    log(name?: string, error?: Error, message?: string, fileName?: string, startLine?: number, startColumn?: number, endLine?: number, endColumn?: number, sourceCode?: string, level?: LogLevel) {
        let err = new BuildError(this, name, error, message, fileName, startLine, startColumn, endLine, endColumn, sourceCode);
        this.builder.log(err.toString(), level);
        return err;
    }

    /**
     * 获取当前文件累积的所有错误信息。
     */
    errors: BuildError[];

    /**
     * 获取当前文件累积的错误数。
     */
    get errorCount() { return this.errors && this.errors.length; }

    /**
     * 记录当前文件生成时发生的错误。
     * @param name 错误的名字。
     * @param error 原始错误对象。
     * @param message 指定错误的详细信息。
     * @param fileName 发生错误的文件名。
     * @param startLine 错误的开始行号。
     * @param startColumn 错误的开始列号。
     * @param endLine 错误的结束行号（不包含结束位置本身）。
     * @param endColumn 错误的结束列号（不包含结束位置本身）。
     * @param sourceCode 错误的源码。
     * @param sourceContent 错误的文件源码。
     */
    error(name?: string, error?: Error, message?: string, fileName?: string, startLine?: number, startColumn?: number, endLine?: number, endColumn?: number, sourceCode?: string, sourceContent?: string) {
        let err = new BuildError(this, name, error, message, fileName, startLine, startColumn, endLine, endColumn, sourceCode, sourceContent);
        if (this.errors) {
            this.errors.push(err);
        } else {
            this.errors = [err];
        }
        this.builder.onFileError(this, err);
        return err;
    }

    /**
     * 获取当前文件累积的所有警告信息。
     */
    warnings: BuildError[];

    /**
     * 获取当前文件累积的警告数。
     */
    get warningCount() { return this.warnings && this.warnings.length; }

    /**
     * 记录当前文件生成时发生的警告。
     * @param name 警告的名字。
     * @param error 原始错误对象。
     * @param message 指定警告的详细信息。
     * @param fileName 发生警告的文件名。
     * @param startLine 警告的开始行号。
     * @param startColumn 警告的开始列号。
     * @param endLine 警告的结束行号（不包含结束位置本身）。
     * @param endColumn 警告的结束列号（不包含结束位置本身）。
     * @param sourceCode 警告的源码。
     * @param sourceContent 错误的文件源码。
     */
    warning(name?: string, error?: Error | any, message?: string, fileName?: string, startLine?: number, startColumn?: number, endLine?: number, endColumn?: number, sourceCode?: string, sourceContent?: string) {
        let err = new BuildError(this, name, error, message, fileName, startLine, startColumn, endLine, endColumn, sourceCode, sourceContent);
        if (this.warnings) {
            this.warnings.push(err);
        } else {
            this.warnings = [err];
        }
        this.builder.onFileWarning(this, err);
        return err;
    }

    // #endregion

    // #region 源码映射表

    /**
     * 存储源码映射表的相关配置。
     */
    private _sourceMapOptions: typeof Builder.prototype.sourceMapOptions;

    /**
     * 获取源码映射表的相关配置。
     */
    get sourceMapOptions() {
        if (!this._sourceMapOptions) {
            this._sourceMapOptions = Object.assign({} as typeof Builder.prototype.sourceMapOptions, this.builder.sourceMapOptions);
        }
        return this._sourceMapOptions;
    }

    /**
     * 设置源码映射表的相关配置。
     */
    set sourceMapOptions(value) {
        this._sourceMapOptions = value;
    }

    /**
     * 判断当前文件是否生成源码映射表。
     */
    get sourceMap() {
        return this.builder.currentAction !== BuildAction.clean && (this._sourceMapOptions && this._sourceMapOptions.enabled != null ? this._sourceMapOptions.enabled : (this.builder.sourceMap && (!this.builder.sourceMapOptions.test || this.builder.sourceMapOptions.test.test(this.name))));
    }

    /**
     * 设置当前文件是否生成源码映射表。
     */
    set sourceMap(value) {
        if (this.sourceMap === value) return;
        this.sourceMapOptions.enabled = value;
    }

    /**
     * 存储当前文件的源码映射表数据。
     */
    private _sourceMapData: SourceMap.RawSourceMap;

    /**
     * 获取当前文件的源码映射表数据。
     */
    get sourceMapData() { return this._sourceMapData; }

    /**
     * 设置当前文件的源码映射表数据。
     */
    set sourceMapData(value) {

        // 修复参数。
        if (!value) return;
        if (typeof value === "string") value = JSON.parse(value as any);

        // 第一次生成源码表。
        if (!this._sourceMapData) {
            this._sourceMapData = value;
            return;
        }

        // TODO: 实现合并逻辑。
        // 合并现有源码表和目标源码表。
        const SourceMapModule = require("source-map") as typeof SourceMap;

        let oldMapConsumer = new SourceMapModule.SourceMapConsumer(this._sourceMapData);
        let newMapConsumer = new SourceMapModule.SourceMapConsumer(value);
        let mergedMapGenerator = new SourceMapModule.SourceMapGenerator();

        newMapConsumer.eachMapping(m => {
            let origPosInOldMap = oldMapConsumer.originalPositionFor({ line: m.originalLine, column: m.originalColumn });

            if (!origPosInOldMap.source) return;

            mergedMapGenerator.addMapping({
                original: {
                    line: origPosInOldMap.line,
                    column: origPosInOldMap.column
                },
                generated: {
                    line: m.generatedLine,
                    column: m.generatedColumn
                },
                source: m.source,
                name: m.name
            });

        });

        this._sourceMapData = mergedMapGenerator.toJSON();
    }

    /**
     * 获取当前文件的源码映射表路径。
     */
    get sourceMapPath() {

        // 自定义路径生成函数。
        let mapFile = this._sourceMapOptions && this._sourceMapOptions.mapFile || this.builder.sourceMapOptions.mapFile;
        if (mapFile) {
            return mapFile.call(this, this.srcPath) as string;
        }

        // 使用预定义名字。
        let name = this._sourceMapOptions && this._sourceMapOptions.name != null ? this._sourceMapOptions.name : this.builder.sourceMapOptions.name;
        if (name) {
            name = this.format(name);
            if (name.charCodeAt(0) === 46/*.*/) {
                name = Path.join(this.name, name);
            }
        } else {
            name = this.name + ".map";
        }
        return Path.resolve(this.builder.destPath, name);
    }

    /**
     * 保存当前文件的源码映射表。
     */
    saveSourceMap() {

        // 无数据不需要保存。
        let sourceMapData = this._sourceMapData;
        if (!sourceMapData) return;

        let _sourceMapOptions = this._sourceMapOptions;
        let globalSourceMapOptions = this.builder.sourceMapOptions;
        let sourceMapPath = this.sourceMapPath;

        // 生成最终源码映射表。
        let finalSourceMap: SourceMap.RawSourceMap = {
            version: sourceMapData.version || "3",
            names: sourceMapData.names || [],
            mappings: sourceMapData.mappings || "",
            sources: sourceMapData.sources.map(_sourceMapOptions && _sourceMapOptions.mapSources || globalSourceMapOptions.mapSources || (source => relative(Path.dirname(sourceMapPath), source)), this)
        };

        // sourceRoot。
        let sourceRoot = _sourceMapOptions && _sourceMapOptions.sourceRoot != null ? _sourceMapOptions.sourceRoot : globalSourceMapOptions.sourceRoot;
        if (sourceRoot) {
            finalSourceMap.sourceRoot = sourceRoot;
        }

        // file。
        if (_sourceMapOptions && _sourceMapOptions.includeFile != null ? _sourceMapOptions.includeFile : globalSourceMapOptions.includeFile) {
            finalSourceMap.file = relative(Path.dirname(sourceMapPath), this.destPath);
        }

        // sourcesContent。
        if (_sourceMapOptions && _sourceMapOptions.includeSources != null ? _sourceMapOptions.includeSources : globalSourceMapOptions.includeSources) {
            finalSourceMap.sourcesContent = sourceMapData.sources.map(source => this.builder.getFile(this.builder.toName(source)).srcContent);
        }

        // 内联源码映射表。
        if (_sourceMapOptions && _sourceMapOptions.inline != null ? _sourceMapOptions.inline : globalSourceMapOptions.inline) {
            this.omitSourceMapUrl("data:application/json;base64," + new Buffer(JSON.stringify(finalSourceMap)).toString("base64"));
            return;
        }

        // 修改源码中的路径。
        if (_sourceMapOptions && _sourceMapOptions.omitSourceMapUrl != null ? _sourceMapOptions.omitSourceMapUrl : globalSourceMapOptions.omitSourceMapUrl) {
            let mapSourceMapUrl = _sourceMapOptions && _sourceMapOptions.mapSourceMapUrl || globalSourceMapOptions.mapSourceMapUrl;
            this.omitSourceMapUrl(mapSourceMapUrl ? mapSourceMapUrl.call(this, sourceMapPath) : (_sourceMapOptions && _sourceMapOptions.sourceMapUrlPrefix != null ? _sourceMapOptions.sourceMapUrlPrefix : globalSourceMapOptions.sourceMapUrlPrefix) + relative(this.destDirPath, sourceMapPath));
        }

        // 写入文件。
        try {
            IO.writeFile(sourceMapPath, JSON.stringify(finalSourceMap), _sourceMapOptions && _sourceMapOptions.encoding || globalSourceMapOptions.encoding || this.builder.encoding);
        } catch (e) {
            this.error("SourceMapWriteError", e);
        }
    }

    /**
     * 向当前文件内容插入源码映射表地址。
     * @param sourceMapUrl 要插入的源码映射表地址。
     */
    omitSourceMapUrl(sourceMapUrl: string) {
        let content = this.content;
        let found = false;
        content = content.replace(/(?:\/\*(?:\s*\r?\n(?:\/\/)?)?(?:[#@]\ssourceMappingURL=([^\s'"]*))\s*\*\/|\/\/(?:[#@]\ssourceMappingURL=([^\s'"]*)))\s*/, (match, url1, url2) => {
            found = true;
            return url2 != null ? `//# sourceMappingURL=${sourceMapUrl}` : `/*# sourceMappingURL=${sourceMapUrl} */`;
        });
        if (!found) {
            content += `/*# sourceMappingURL=${sourceMapUrl} */`;
        }
        this.content = content;
    }

    // #endregion

    // #region 文本内容

    /**
     * 计算指定索引对应的行列号。
     * @param index 要检查的索引。
     */
    indexToLocation(index: number): { line: number, column: number } {
        return indexToLocation(this.content, index);
    }

    /**
     * 在当前文件指定位置插入内容。
     * @param index 要插入的位置。
     * @param value 要插入的内容。
     * @param source 插入内容的来源。
     * @param line 插入内容的在源文件的行号。
     * @param column 插入内容的在源文件的列号。
     */
    insert(index: number, value: string, source?: string | BuildFile, line?: number, column?: number) {
        this.content = this.content.substr(0, index) + value + this.content.substr(index);
        // TODO: 支持 sourceMap
        return this;
    }

    /**
     * 在当前文件末尾插入内容。
     * @param value 要插入的内容。
     * @param source 插入内容的来源。
     * @param line 插入内容的在源文件的行号。
     * @param column 插入内容的在源文件的列号。
     */
    append(value: string, source?: string | BuildFile, line?: number, column?: number) {
        this.content += value;
        // 更新源码映射表。
        if (this.sourceMapData) {
            // TODO: 支持 sourceMap
            //    const SourceMap = require("source-map");
            //    let map = new SourceMap.SourceMapGenerator(this._sourceMapData);
            //    let mapping: any = {
            //        generated: this.indexToLocation(this.content.length)
            //    };
            //    mapping.generated.column--;
            //    if (source) {
            //        mapping.source = source instanceof BuildFile ? source.srcName : source;
            //        mapping.original = {
            //            line: line || 1,
            //            column: (column || 1) - 1
            //        };
            //    }
            //    map.addMapping(mapping);
            //    this._sourceMapData = map.toJSON();
        }
        return this;
    }

    /**
     * 删除当前文件指定位置区间的内容。
     * @param startIndex 要删除的起始位置。
     * @param endIndex 要删除的结束位置（不含位置本身）。
     */
    remove(startIndex: number, endIndex: number) {
        this.content = this.content.substr(0, startIndex) + this.content.substr(endIndex);
        // 更新源码映射表。
        if (this.sourceMapData) {
            // TODO: 支持 sourceMap
        }
        return this;
    }

    /**
     * 替换当前文件的内容。
     * @param searchValue 要替换的源。
     * @param replaceValue 替换的目标。
     * @param source 替换内容的来源。
     * @param line 替换内容的在源文件的行号。
     * @param column 替换内容的在源文件的列号。
     * @returns this
     */
    replace(searchValue: string | RegExp, replaceValue: string | ((match: string, ...rest: string[]) => string), source?: string | BuildFile, line?: number, column?: number) {
        this.content = this.content.replace(searchValue as any, replaceValue as any);
        // 更新源码映射表。
        if (this.sourceMapData) {
            // TODO: 支持 sourceMap
        }
        return this;
    }

    // #endregion

    // #region 插件支持

    /**
     * 根据当前文件的信息格式化指定的字符串。
     * @param value 要格式化的字符串。
     * @returns 返回格式化后的字符串。
     */
    format(value: string) {
        return value.replace(/\$(\w+)/g, (all, macro) => {
            switch (macro) {
                case "FILE": return Path.basename(this.name);
                case "EXT": return this.extension;
                case "DIR": return Path.dirname(this.name);
                case "NAME": return this.name;
                case "PATH": return this.path;
                case "HASH":
                    return this.builder.sessionStorage["_hash"] || (this.builder.sessionStorage["_hash"] = this.buildVersion.toString(16) + (+new Date()).toString(16) + (~~(Math.random() * 1000)).toString(16));
                case "VERSION": return this.buildVersion;
                case "MD5": return this.getMd5().substr(0, 8);
                default:
                    let date: Date = this.builder.sessionStorage["_date"] || (this.builder.sessionStorage["_date"] = new Date());
                    return macro === "DATE" ?
                        `${date.getFullYear()}${padZero(date.getMonth() + 1)}${padZero(date.getDate())}` :
                        macro === "DATETIME" ?
                            `${date.getFullYear()}${padZero(date.getMonth() + 1)}${padZero(date.getDate())}${padZero(date.getHours())}${padZero(date.getMinutes())}${padZero(date.getSeconds())}` :
                            macro === "NOW" ? `${date.getFullYear()}-${padZero(date.getMonth() + 1)}-${padZero(date.getDate())} ${padZero(date.getHours())}:${padZero(date.getMinutes())}:${padZero(date.getSeconds())}` :
                                macro === "TIME" ? (+date).toString() : all;
            }
        });
    }

    /**
     * 计算当前文件内容的 MD5 值。
     * @returns 返回小写字母组成的 MD5 值。
     */
    getMd5() {
        let md5sum = (require("crypto").createHash as typeof createHash)("md5");
        md5sum.update(this.data);
        return md5sum.digest("hex") as string;
    }

    /**
     * 获取通过 Base64 编码获取当前资源的地址。
     * @returns 返回 Base64 编码的地址。 
     */
    getBase64Url() {
        return "data:" + this.builder.getMimeTypeByExt(this.extension) + ";base64," + this.buffer.toString("base64");
    }

    // #endregion

}

/**
 * 表示一个生成错误。
 */
export class BuildError extends Error {

    /**
     * 获取当前错误的所属文件。
     */
    file: BuildFile;

    /**
     * 获取当前错误的名字。
     */
    name: string;

    /**
     * 获取当前错误的堆栈。
     */
    stack: string;

    /**
     * 获取当前错误的信息。
     */
    message: string;

    /**
     * 获取当前发生错误的源文件。
     */
    fileName: string;

    /**
     * 获取当前错误的开始行号。
     */
    startLine: number;

    /**
     * 获取当前错误的开始列号。
     */
    startColumn: number;

    /**
     * 获取当前错误的结束行号（不包含结束位置本身）。
     */
    endLine: number;

    /**
     * 获取当前错误的结束列号（不包含结束位置本身）。
     */
    endColumn: number;

    /**
     * 获取当前错误的源位置。
     */
    get sourcePath() {
        let result = this.file.displayName;
        let fileName = this.file.builder.toDisplayName(this.fileName);
        if (result !== fileName) {
            result += ": " + fileName;
        }
        if (this.startLine != null) {
            result += "(" + this.startLine;
            if (this.startColumn != null) {
                result += "," + this.startColumn;
            }
            result += ")";
        }
        return result;
    }

    /**
     * 存储当前错误的相关源码。
     */
    _sourceCode: string;

    /**
     * 获取当前错误的相关源码。
     */
    get sourceCode() {
        if (this._sourceCode != null) {
            return this._sourceCode;
        }

        if (this.startLine == null) {
            return null;
        }

        // TODO: 自动生成 sourceCode
    };

    /**
     * 获取当前错误的文件源码。
     */
    _sourceContent: string;

    /**
     * 获取当前错误的文件源码。
     */
    get sourceContent() {
        if (this._sourceContent == null) {
            this._sourceContent = this.file ? this.file.srcContent : "";
        }
        return this._sourceContent;
    };

    /**
     * 获取引发当前错误的原始错误。
     */
    innerError: Error;

    /**
     * 初始化新错误对象。
     * @param file 错误所属的文件。
     * @param name 错误的名字。
     * @param message 指定错误的信息。
     * @param fileName 发生错误的文件名。
     * @param startLine 错误的开始行号。
     * @param startColumn 错误的开始列号。
     * @param endLine 错误的结束行号（不包含结束位置本身）。
     * @param endColumn 错误的结束列号（不包含结束位置本身）。
     * @param sourceCode 错误的源码。
     * @param sourceContent 错误的文件源码。
     */
    constructor(file: BuildFile, name?: string, error?: Error, message?: string, fileName?: string, startLine?: number, startColumn?: number, endLine?: number, endColumn?: number, sourceCode?: string, sourceContent?: string) {
        super();
        if (error) {
            this.innerError = error;
            this.stack = error["stack"];
            if (message == null) {
                message = error.message || error["description"] || error.toString();
            }
            if (fileName == null) {
                fileName = error["filename"] || error["file"] || error["source"];
            }
            if (startLine == null) {
                startLine = error["line"] || error["linenumber"] || error["lineno"] || error["row"];
            }
            if (startColumn == null) {
                startColumn = error["column"] || error["col"];
            }
        }
        if (file != null) this.file = file;
        if (message != null) this.message = this.file.builder.dict[message] || message;
        if (name != null) this.name = name;
        if (fileName != null) this.fileName = Path.normalize(fileName);
        else if (file) this.fileName = file.srcPath;
        if (startLine != null) this.startLine = startLine;
        if (startColumn != null) this.startColumn = startColumn;
        if (endLine != null) this.endLine = endLine;
        if (endColumn != null) this.endColumn = endColumn;
        if (sourceCode != null) this._sourceCode = sourceCode;
        if (sourceContent != null) this._sourceContent = sourceContent;
    }

    /**
     * 获取当前错误的字符串形式。
     */
    toString() {
        let msg = this.sourcePath + ": ";
        if (this.name && this.name !== "Error") {
            msg += "[" + this.name + "]";
        }
        if (this.message) {
            msg += this.message;
        }
        return msg;
    }

}

/**
 * 表示一个源码类型引用。
 */
export interface ReferenceList extends Array<string> {

    /**
     * 获取当前列表的源码信息。
     */
    sources?: Object[]

}

/**
 * 计算指定索引对应的行列号。
 * @param content 要检查的内容。
 * @param index 要检查的索引。
 * @return 返回包含行列的信息。
 */
export function indexToLocation(content: string, index: number): { line: number, column: number } {
    let line = 0;
    let column = 0;
    for (let i = 0; i < index; i++) {
        switch (content[i]) {
            case "\r":
                if (content[i + 1] !== "\n") {
                    continue;
                }
                i++;
            // fall through
            case "\n":
                line++;
                column = 1;
                break;
            default:
                column++;
                break;
        }
    }
    return { line, column };
}
