/**
 * @fileOverview 生成器核心。
 */

import * as Path from "path";
import * as FS from "fs";
import {ChildProcess, exec, fork} from "child_process";
import {WriteStream} from "tty";
import {Agent as HttpAgent} from "http";
import {Agent as HttpsAgent} from "https";

import "tutils/lang/es5";
import {EventEmitter} from "tutils/lang/events";
import * as IO from "tutils/node/io";

import {BuildRule, Processor} from "./buildRule";
import {BuildFile, BuildError} from "./buildFile";
import {Watcher} from "./watcher";
import {Server} from "./server";

/**
 * 表示一个生成器。
 */
export class Builder extends EventEmitter {

    // #region 路径

    /**
     * 存储当前生成器的基路径。所有路径都相对于此路径。
     */
    private _basePath: string;

    /**
     * 获取当前生成器的基路径。所有路径都相对于此路径。
     */
    get basePath() { return this._basePath || (this._basePath = process.cwd()); }

    /**
     * 设置当前生成器的基路径。所有路径都相对于此路径。
     * @remark 必须在设置所有路径之前首先设置 @basePath。
     */
    set basePath(value) { this._basePath = Path.resolve(value || ""); }

    /**
     * 存储当前生成器的源文件夹路径。
     */
    private _srcPath: string;

    /**
     * 获取当前生成器的源文件夹路径。
     */
    get srcPath() { return this._srcPath || (this._srcPath = this.basePath); }

    /**
     * 设置当前生成器的源文件夹路径。
     */
    set srcPath(value) { this._srcPath = Path.resolve(this.basePath, value); }

    /**
     * 存储当前生成器的目标文件夹路径。
     */
    private _destPath: string;

    /**
     * 获取当前生成器的目标文件夹路径。
     */
    get destPath() { return this._destPath || (this._destPath = this.basePath); }

    /**
     * 设置当前生成器的目标文件夹路径。
     */
    set destPath(value) {
        let oldDestPath = this._destPath;
        this._destPath = value = Path.resolve(this.basePath, value);

        // 如果生成的目标文件夹在源文件夹内，则需要自动忽略目标文件夹。
        this.updateSystemIgnore(oldDestPath, value);
    }

    /**
     * 获取指定路径的名称。
     * @param path 要转换的绝对路径或名称。
     * @returns 返回路径基于 @this.srcPath 的相对路径，格式如：“a/b.jpg”；如果 @path 在 @this.srcPath 外则返回绝对路径。
     */
    toName(path: string) {
        return containsDir(this.srcPath, path) ? relative(this.srcPath, path) : Path.normalize(path).replace(/\\/g, "/");
    }

    /**
     * 获取指定名称的绝对路径。
     * @param name 要转换的名称或绝对路径。
     * @returns 返回绝对路径。格式如：“E:\www\a\b.jpg”。
     */
    toPath(name: string) { return Path.resolve(this.srcPath, name); }

    /**
     * 判断或设置是否显示完整路径。
     * @default false
     */
    fullPath: boolean;

    /**
     * 获取指定路径的友好显示名称。
     * @param path 要转换的名称或绝对路径。
     * @returns 如果 @this.fullPath 为 false 且 @path 在 @this.srcPath 内，则返回基于 @this.srcPath 的相对路径，否则返回绝对路径。
     */
    toDisplayName(path: string) { return this.fullPath ? this.toPath(path) : this.toName(path); }

    /**
     * 判断或设置是否允许生成目标文件夹以外的文件。
     * @default true
     */
    checkingSavePath: boolean;

    /**
     * 检查指定的路径是否允许保存。
     * @param path 要检查的路径。
     * @return 如果检查成功则返回 @true，否则返回 @false。
     */
    checkSavePath(path: string) { return this.checkingSavePath === false || containsDir(this.destPath, path); }

    // #endregion

    // #region 调试

    /**
     * 存储是否启用调试模式。
     * @default false
     */
    private _verbose: boolean;

    /**
     * 判断是否启用调试模式。
     */
    get verbose() { return this._verbose; }

    /**
     * 设置是否启用调试模式。
     */
    set verbose(value) {
        if (!!this._verbose === value) return;
        this._verbose = value;

        // 如果启动调试模式，则在执行 xx() 时，同时执行 xxVerbose()。
        for (let funcName in this) {
            if (typeof this[funcName + "Verbose"] === "function" && typeof this[funcName] === "function") {
                this[funcName] = value ? function () {
                    try {
                        this[funcName + "Verbose"].apply(this, arguments);
                    } catch (e) { }
                    return this["__proto__"][funcName].apply(this, arguments);
                } : this["__proto__"][funcName];
            }
        }

    }

    /**
     * 存储调试输出的日志文件地址。
     */
    private _verboseFilePath: string;

    /**
     * 获取调试输出的日志文件地址。
     */
    get verboseFilePath() { return this._verboseFilePath || (this._verboseFilePath = Path.resolve(this.basePath, "tpack-verbose.log")); }

    /**
     * 设置调试输出的日志文件地址。
     */
    set verboseFilePath(value) { this._verboseFilePath = value; }

    // #endregion

    // #region 日志

    /**
     * 获取或设置当前生成器允许输出的最低日志等级。
     * @default LogLevel.progress
     */
    logLevel: LogLevel;

    /**
     * 判断或设置是否启用颜色化输出。
     * @default true
     */
    coloredOutput: boolean;

    /**
     * 获取当前生成器累积的所有错误日志。
     */
    errors: string[] = [];

    /**
     * 获取当前生成器累积的错误数。
     */
    get errorCount() { return this.errors.length; }

    /**
     * 获取当前生成器累积的所有警告日志。
     */
    warnings: string[] = [];

    /**
     * 获取当前生成器累积的警告数。
     */
    get warningCount() { return this.warnings.length; }

    /**
     * 记录一条日志。
     * @param message 要记录的日志内容。
     * @param level 要记录的日志等级。
     */
    log(message: string, level?: LogLevel) {

        // 日志等级，触发事件。
        if (level < this.logLevel || !this.trigger("log", message, level)) return;

        // 日志颜色。
        if (this.coloredOutput === false) {
            message = message.replace(/\u001b\[[\d;]*?m/g, "");
        } else if (level !== LogLevel.log && message.indexOf('\u001b[') < 0) {
            switch (level) {
                case LogLevel.progress:
                    message = `\u001b[32m${message}\u001b[0m`;
                    break;
                case LogLevel.error:
                    message = `\u001b[1m\u001b[31m${message}\u001b[0m`;
                    break;
                case LogLevel.warning:
                    message = `\u001b[1m\u001b[33m${message}\u001b[0m`;
                    break;
                case LogLevel.info:
                    message = `\u001b[36m${message}\u001b[0m`;
                    break;
                case LogLevel.success:
                    message = `\u001b[1m\u001b[32m${message}\u001b[0m`;
                    break;
                case LogLevel.fatal:
                    message = `\u001b[31m${message}\u001b[0m`;
                    break;
            }
        }

        // 打印日志。
        switch (level) {
            case LogLevel.info:
            case LogLevel.success:
            case LogLevel.fatal:
                return console.info(message);
            case LogLevel.error:
                return console.error(message);
            case LogLevel.warning:
                return console.warn(message);
            default:
                return console.log(message);
        }
    }

    /**
     * 调试输出。
     * @param message 要记录的日志内容。
     * @param level 要记录的日志等级。
     */
    logVerbose(message: string, level?: LogLevel) {
        FS.appendFileSync(this.verboseFilePath, this.time + message.replace(/\u001b\[[\d;]*?m/g, "") + "\n");
    }

    /**
     * 记录一条信息日志。
     * @param message 要记录的日志内容。
     * @param args 格式化参数。如设置 {a:1}，那么 @message 中的 {a} 会被替换为 1。
     */
    info(message: string, args?: Object) { return this.log(this.format(message, args), LogLevel.info); }

    /**
     * 记录一条成功日志。
     * @param message 要记录的日志内容。
     * @param args 格式化参数。如设置 {a:1}，那么 @message 中的 {a} 会被替换为 1。
     */
    success(message: string, args?: Object) { return this.log(this.format(message, args), LogLevel.success); }

    /**
     * 记录一条致命错误日志。
     * @param message 要记录的日志内容。
     * @param args 格式化参数。如设置 {a:1}，那么 @message 中的 {a} 会被替换为 1。
     */
    fatal(message: string, args?: Object) {
        message = this.format(message, args);
        this.errors.push(message);
        return this.log(message, LogLevel.fatal);
    }

    /**
     * 记录一条警告日志。
     * @param message 要记录的日志内容。
     * @param args 格式化参数。如设置 {a:1}，那么 @message 中的 {a} 会被替换为 1。
     */
    warning(message: string, args?: Object) {
        message = this.format(message, args);
        if (!this.trigger("warning", message)) return;
        this.warnings.push(message);
        this.log(`\u001b[33m[${this.warningCount + this.errorCount}] \u001b[1m${message}\u001b[0m`, LogLevel.warning);
    }

    /**
     * 记录一条错误日志。
     * @param message 要记录的日志内容。
     * @param args 格式化参数。如设置 {a:1}，那么 @message 中的 {a} 会被替换为 1。
     */
    error(message: string, args?: Object) {
        message = this.format(message, args);
        if (!this.trigger("error", message)) return;
        this.errors.push(message);
        this.log(`\u001b[31m[${this.warningCount + this.errorCount}] \u001b[1m${message}\u001b[0m`, LogLevel.error);
    }

    /**
     * 获取或设置所有日志的本地翻译版本。
     */
    dict: { [message: string]: string } = { __proto__: null };

    /**
     * 格式化指定的内容。
     * @param message 要格式化的内容。
     * @param args 格式化参数。如设置 {a:1}，那么 @message 中的 {a} 会被替换为 1。
     * @return 返回已格式化的内容。
     */
    format(message: string, args?: Object) {
        message = this.dict[message] || message;
        return args ? message.replace(/\{(\w+)\}/g, (_, key) => args[key]) : message;
    }

    // #endregion

    // #region 进度条

    /**
     * 存储是否启用控制台进度条。
     */
    private _useProgress: boolean;

    /**
     * 判断或设置是否启用控制台进度条。
     */
    get useProgress() { return this._useProgress !== false && (process.stdout as WriteStream).isTTY === true; }

    /**
     * 判断或设置是否启用控制台进度条。
     */
    set useProgress(value) { this._useProgress = value; }

    /**
     * 存储进度条更新子进程。
     */
    private _progressProcess: ChildProcess;

    /**
     * 启用进度条。
     */
    beginProgress() {

        // 不支持进度或已启动进度条则返回。
        if (!this.useProgress || this._progressProcess) return;

        // 启动控制台进度。
        this._progressProcess = (require('child_process').fork as typeof fork)(require.resolve('./progress'));

        // 重写控制台输出，以便在输出内容前先清除进度条信息。
        process.stdout.write = (buffer: Buffer | string, encoding?: string | Function, cb?: Function) => {
            this._progressProcess.send({ command: 2, buffer: buffer, encoding: encoding }, cb);
            return true;
        };

        process.stderr.write = (buffer: Buffer | string, encoding?: string | Function, cb?: Function) => {
            this._progressProcess.send({ command: 3, buffer: buffer, encoding: encoding }, cb);
            return true;
        };

    }

    /**
     * 关闭进度条。
     */
    endProgress() {
        let progressProcess = this._progressProcess;
        if (!progressProcess) return;

        let injects = [];

        // 在进度条关闭前先停止输出内容。
        this.beginProgress = () => {
            injects.push(() => { this.beginProgress(); });
        };
        this.progress = () => {};

        // 在进度条关闭前先停止输出内容。
        process.stdout.write = (buffer: Buffer | string, encoding?: string | Function, cb?: Function) => {
            injects.push(() => { process.stdout.write(buffer as any, encoding as any, cb); });
            return true;
        };

        // 在进度条关闭前先停止输出内容。
        process.stderr.write = (buffer: Buffer | string, encoding?: string | Function, cb?: Function) => {
            injects.push(() => { process.stderr.write(buffer as any, encoding as any, cb); });
            return true;
        };

        // 发送结束命令。
        progressProcess.send({ command: 1 });

        // 等待进度条结束后继续。
        progressProcess.on("exit", () => {

            // 恢复默认的输出器。
            this.beginProgress = this["__proto__"].beginProgress;
            this.progress = this["__proto__"].progress;
            process.stdout.write = process.stdout["__proto__"].write;
            process.stderr.write = process.stderr["__proto__"].write;

            for (let i = 0; i < injects.length; i++) {
                injects[i]();
            }

            this._progressProcess = null;
        });

    }

    /**
     * 记录一个进度信息。
     * @param message 要记录的日志内容。
     */
    progress(message: string) {
        let progressProcess = this._progressProcess;
        if (progressProcess) {
            progressProcess.send(message);
        }
    }

    // #endregion

    // #region 计时器

    /**
     * 记录本次开始生成的时间。
     */
    private _startTime: number[];

    /**
     * 启动计时器。
     */
    startTimer() { this._startTime = process.hrtime(); }

    /**
     * 获取从启动计时器到现在所经过的时间。
     * @return 返回字符串。格式如“0.5s”。
     */
    get elapsed() { return this.calcElapsed(this._startTime); }

    /**
     * 获取从启动计时器到现在所经过的时间。
     * @param startTime 开始时间。
     * @return 返回字符串。格式如“0.5s”。
     */
    calcElapsed(startTime: number[]) {
        let hrtime = process.hrtime(startTime);
        let s = hrtime[0];
        let ns = hrtime[1];
        return s < 1 ?
            ns < 1000000 ?
                (Math.floor(ns / 10000) / 100).toFixed(2) + (this.dict["ms"] || "ms") : // 0.32ms
                Math.floor(ns / 1000000) + (this.dict["ms"] || "ms") : // 123ms
            s < 60 ? (s + Math.floor(ns / 10000000) / 100).toFixed(2) + (this.dict["s"] || "s") : // 6.32s
                (Math.floor(s / 60 * 100) / 100).toFixed(2) + (this.dict["min"] || "min"); // 7.24min
    }

    /**
     * 获取当前时间戳。
     */
    get time() {
        let date = new Date();
        return `[${padZero(date.getHours())}:${padZero(date.getMinutes())}:${padZero(date.getSeconds())}]`;
    }

    // #endregion

    // #region 筛选，忽略和规则

    /**
     * 获取或设置当前生成器的忽略列表。列表可以包含通配符、正则表达式、自定义函数或以上组合的列表。
     */
    ignores: FilterSet = [];

    /**
     * 添加忽略的文件或文件夹。
     * @param filters 要忽略的文件或文件夹名称。可以使用通配符、正则表达式、自定义函数或以上组合的列表。
     */
    ignore(...filters: Filter[]): this;

    /**
     * 添加忽略的文件或文件夹。
     * @param filters 要忽略的文件或文件夹名称。可以使用通配符、正则表达式、自定义函数或以上组合的列表。
     */
    ignore() {
        this.ignores.push.apply(this.ignores, arguments);
        delete this.ignores.compiled;
        return this;
    }

    /**
     * 判断指定的文件或文件夹是否被忽略。
     * @param name 要判断的文件或文件夹名称。
     * @returns 如果指定的文件或文件夹名称已被忽略则返回 @true，否则返回 @false。
     */
    ignored(name: string) {
        return (this.ignores.compiled || (this.ignores.compiled = compileFilters(this.ignores, false, this.srcPath))).call(this, name) as boolean;
    }

    /**
     * 调试输出。
     * @param name 要判断的文件或文件夹名称。
     * @returns 如果指定的文件或文件夹名称已被忽略则返回 @true，否则返回 @false。
     */
    private ignoredVerbose(name: string) {
        if (this["__proto__"].ignored.call(this, name)) {
            this.logVerbose(this.toPath(name) + ": Ignored by tpack.ignore()");
        }
    }

    /**
     * 更新系统自动忽略指定的绝对路径。
     * @param oldPath 原忽略路径。 
     * @param newPath 要忽略的新路径。
     */
    updateSystemIgnore(oldPath, newPath) {
        if (oldPath) {
            let p = this.ignores.indexOf(oldPath);
            p >= 0 && this.ignores.splice(p, 1);
        }
        if (containsDir(this.srcPath, newPath + ".")) {
            this.ignores.push(newPath);
        }
        delete this.ignores.compiled;
    }

    /**
     * 获取或设置当前生成器的筛选列表。列表可以包含通配符、正则表达式、自定义函数或以上组合的列表。
     */
    filters: FilterSet;

    /**
     * 判断当前是否是全量生成。
     * @returns 如果是全量生成则返回 @true，否则返回 @false。
     */
    get global() { return !this.filters }

    /**
     * 判断指定的文件或文件夹名称是否被筛选。
     * @param name 要判断的文件或文件夹名称。
     * @returns 如果指定的文件或文件夹名称已被筛选则返回 @true，否则返回 @false。
     */
    filtered(name: string) {
        return !this.filters || !this.filters.length || (this.filters.compiled || (this.filters.compiled = compileFilters(this.filters, false, this.srcPath))).call(this, name) as boolean;
    }

    /**
     * 调试输出。
     * @param name 要判断的文件或文件夹名称。
     * @returns 如果指定的文件或文件夹名称已被筛选则返回 @true，否则返回 @false。
     */
    private filteredVerbose(name: string) {
        if (!this["__proto__"].filtered.call(this, name)) {
            this.logVerbose(this.toPath(name) + ": Ignored by tpack.filters");
        }
    }

    /**
     * 获取当前生成器已定义的所有规则。
     */
    rules: BuildRule[] = [];

    /**
     * 添加针对指定名称的处理规则。
     * @param filters 筛选列表。列表可以包含通配符、正则表达式、自定义函数或以上组合的列表。
     * @returns 返回一个规则，可针对此规则添加处理器。
     */
    src(...filters: Filter[]): BuildRule;

    /**
     * 添加针对指定名称的处理规则。
     * @param filters 筛选列表。列表可以包含通配符、正则表达式、自定义函数或以上组合的列表。
     * @returns 返回一个规则，可针对此规则添加处理器。
     */
    src() {
        let rule = new BuildRule(this, Array.prototype.slice.call(arguments));
        this.rules.push(rule);
        return rule;
    }

    /**
     * 清空所有规则。
     */
    clear() {
        this.rules.length = 0;
        return this;
    }

    // #endregion

    // #region 生成公用

    /**
     * 获取当前正在执行的操作。
     */
    currentAction: BuildAction;

    /**
     * 获取或设置当前生成器读写文件使用的默认编码。
     */
    encoding = "utf-8";

    /**
     * 获取当前生成器的生成版本。
     */
    buildVersion = 0;

    /**
     * 本次生成的文件数。
     */
    buildFileCount = 0;

    /**
     * 判断或设置是否允许覆盖源文件。
     * @default false
     */
    allowOverwrite: boolean;

    /**
     * 获取所有文件对象。
     */
    files: { [name: string]: BuildFile } = { __proto__: null };

    /**
     * 存储生成的文件列表。
     */
    gernerated: { [name: string]: BuildFile } = { __proto__: null };

    /**
     * 获取指定文件对象。
     * @param name 文件的名称。
     */
    getFile(name: string) {

        // 获取文件。
        let file = this.files[name];
        if (!file) {
            this.files[name] = file = new BuildFile(this, name);
            this.processFile(file);
            return file;
        }

        // 文件是最新版本。
        if (file.buildVersion >= this.buildVersion) {
            return file;
        }

        // 创建新文件。
        let newFile = this.files[name] = new BuildFile(this, name);
        this.processFile(newFile);

        // 如果新文件存在错误，则复制之前部分文件的信息。
        if (newFile.errorCount) {
            newFile.refs = newFile.refs || file.refs;
            newFile.includes = newFile.includes || file.includes;
            newFile.related = newFile.related || file.related;
        }

        return newFile;
    }

    /**
     * 创建一个文件。
     * @param name 文件的名称。
     * @param data 文件的数据。
     */
    createFile(name?: string, data?: string | Buffer) {
        return name ? this.files[name] = new BuildFile(this, name, data || "") : new BuildFile(this, "", data || "");
    }

    /**
     * 重置当前的生成状态。
     */
    reset() {
        this.buildVersion++;
        this.errors.length = this.warnings.length = this.buildFileCount = 0;
    }

    /**
     * 调试输出。
     */
    private resetVerbose() {
        FS.writeFileSync(this.verboseFilePath, "");
    }

    /**
     * 遍历一个文件夹内的所有文件。
     * @param name 要遍历的文件夹名字。名字以 '/' 结尾。
     * @param callback 处理每个匹配文件的回调函数。
     */
    walkDir(name: string, callback: (name: string) => void) {
        let basePath = this.srcPath + Path.sep;

        // 获取所有项。
        let fileEntries: string[];
        try {
            fileEntries = FS.readdirSync(basePath + name);
        } catch (e) {
            this.fatal(e.message);
            return;
        }

        // 依次处理每个文件和文件夹。
        for (let i = 0; i < fileEntries.length; i++) {
            let entryName = name + fileEntries[i];

            // 当前子文件或文件夹已被忽略。
            if (this.ignored(entryName)) {
                continue;
            }

            // 判断文件或文件夹。
            let stats: FS.Stats;
            try {
                stats = FS.statSync(basePath + entryName);
            } catch (e) {
                this.fatal(e.message);
                continue;
            }

            // 处理文件夹。
            if (stats.isDirectory()) {
                this.walkDir(entryName + "/", callback);
                continue;
            }

            // 处理文件。
            if (this.filtered(entryName)) {
                callback.call(this, entryName);
            }

        }

    }

    /**
     * 使用预设的规则处理指定的文件。
     * @param file 要处理的文件。
     */
    processFile(file: BuildFile) {
        file.buildVersion = this.buildVersion;
        for (let rules = this.rules, i = 0; i < rules.length; i++) {
            if (rules[i].match(file.name)) {
                this.processFileWithRule(file, rules[i]);
            }
        }
        this.gernerated[file.name] = file;
    }

    /**
     * 使用指定的规则处理指定的文件。
     * @param file 要处理的文件。
     * @param rule 要执行的规则。
     */
    processFileWithRule(file: BuildFile, rule: BuildRule) {

        // 预设当前规则相关的信息。
        file.processed = true;
        file.rule = rule;
        file.initalName = file.name;

        for (let i = 0; i < rule.processors.length; i++) {
            let processor = rule.processors[i];
            this.processFileWithProcessor(file, processor.processor, processor.options);
        }

    }

    /**
     * 使用指定的处理器处理指定的文件。
     * @param file 要处理的文件。
     * @param processor 要执行的处理器。
     * @param options 传递给处理器的只读配置对象。
     */
    processFileWithProcessor(file: BuildFile, processor: Processor, options: Object) {

        // 打印日志。
        let name = processor.plugin || processor.name;
        this.progress(this.format(name ? "{file} -> {processor}" : "{file}", { file: file.displayName, processor: name }));

        // 执行用户定义的处理器。
        if (this.verbose) {
            processor.call(this, file, options);
        } else {
            try {
                processor.call(this, file, options);
            } catch (e) {
                file.error("UncaughtError", e);
            }
        }
    }

    // #endregion

    // #region 源码映射表

    /**
     * 获取或设置源码映射表相关配置。
     */
    sourceMapOptions = {

        /**
         * 是否启用源码映射表。
         */
        enabled: false,

        /**
         * 设置需要生成源码映射表的源文件扩展名。
         */
        test: /^\.(js|css)$/i,

        /**
         * 源码表保存名称。相当于源文件。其中 $FILE$EXT 表示源文件名。
         * @default $FILE$EXT.map
         */
        name: "",

        /**
         * 用于生成源码表本身路径的回调函数。
         */
        mapFile: null as (sourcePath: string) => string,

        /**
         * 用于生成源码本身路径的回调函数。
         */
        mapSources: null as (sourcePath: string) => string,

        /**
         * 源码映射表中引用源的跟地址。
         */
        sourceRoot: "",

        /**
         * 是否在源码映射表内包含文件。
         */
        includeFile: true,

        /**
         * 是否在源码映射表内包含源码。
         */
        includeSources: false,

        /**
         * 是否在源文件中内联源码映射表。
         */
        inline: false,

        /**
         * 是否在源文件追加对源码表的引用地址。默认只对 "js" 和 "css" 添加。
         */
        omitSourceMapUrl: true,

        /**
         * 源码映射表的编码。
         */
        encoding: "utf-8",

        /**
         * 引用源码表的地址前缀。
         */
        sourceMapUrlPrefix: "",

        /**
         * 生成原目标的回调函数。
         */
        mapSourceMapUrl: null as (url: string) => string,

    }

    /**
     * 获取是否输出源码映射表。
     */
    get sourceMap() { return this.sourceMapOptions.enabled }

    /**
     * 设置是否输出源码映射表。
     */
    set sourceMap(value) { this.sourceMapOptions.enabled = value; }

    // #endregion

    // #region 插件支持

    /**
     * 存储生成时使用的会话对象。
     */
    private _sessionStorage: { buildVersion: number };

    /**
     * 获取存储当前生成信息的会话对象。
     */
    get sessionStorage(): {} {
        if (!this._sessionStorage || this._sessionStorage.buildVersion < this.buildVersion) {
            this._sessionStorage = { buildVersion: this.buildVersion };
        }
        return this._sessionStorage;
    }

    /**
     * 存储所有 MIME 类型表。格式如: {".js": "text/javascript"}
     */
    _mimeTypes: { [key: string]: string };

    /**
     * 获取当前生成器使用的所有 MIME 类型表。格式如: {".js": "text/javascript"}
     */
    get mimeTypes() {
        if (this._mimeTypes == null) {
            try {
                this._mimeTypes = require("aspserver/configs").mimeTypes;
            } catch (e) {
                this._mimeTypes = { __proto__: null };
            }
        }
        return this._mimeTypes;
    }

    /**
     * 根据 MIME 类型获取扩展名。
     * @param mimeType 要获取的 MIME 类型。
     * @returns 返回扩展名。
     */
    getExtByMimeType(mimeType: string) {
        for (let ext in this.mimeTypes) {
            if (this.mimeTypes[ext] === mimeType) {
                return ext;
            }
        }
        return "." + mimeType.replace(/^.*\//, "");
    }

    /**
     * 根据扩展名获取 MIME 类型。
     * @param ext 要获取扩展名，包含前导点。
     * @returns 返回  MIME 类型。
     */
    getMimeTypeByExt(ext: string) {
        return this.mimeTypes[ext] || ext.replace(".", "application/x-");
    }

    // #endregion

    // #region 外部调用

    /**
     * 当生成文件出现错误时执行。
     * @param file 相关的文件。
     * @param error 相关的错误。
     */
    onFileError(file: BuildFile, error: BuildError) {
        if (this.currentAction === BuildAction.clean || !this.trigger("fileerror", file, error)) return;
        if (this.currentAction === BuildAction.watch || this.currentAction === BuildAction.server) {
            this.log(this.time + this.format("E {error}", { error }), LogLevel.error);
        } else {
            this.error(error.toString());
        }
        let hint = error.sourceCode || error.stack;
        if (hint) this.log("\n" + hint + "\n", LogLevel.log);
    }

    /**
     * 当生成文件出现警告时执行。
     * @param file 相关的文件。
     * @param error 相关的警告。
     */
    onFileWarning(file: BuildFile, error: BuildError) {
        if (this.currentAction === BuildAction.clean || !this.trigger("filewarning", file, error)) return;
        if (this.currentAction === BuildAction.watch || this.currentAction === BuildAction.server) {
            this.log(this.time + this.format("W {error}", { error }), LogLevel.warning);
        } else {
            this.warning(error.toString());
        }
        let hint = error.sourceCode;
        if (hint) this.log("\n" + hint + "\n", LogLevel.log);
    }

    /**
     * 当文件验证时执行。
     * @param file 相关的文件。
     */
    onFileValidate(file: BuildFile) { return this.trigger("filevalidate", file); }

    /**
     * 当文件保存后执行。
     * @param file 相关的文件。
     */
    onFileSave(file: BuildFile) {
        if (!this.trigger("filesave", file)) return;

        // 如果文件存在错误则不提示文案。
        // 对于生成的文件，仅在完整生成时提示以保证控制台清爽。
        if (!this._progressProcess && !file.errorCount) {
            this.log(this.time + this.format(
                this.fullPath ?
                    file.isGenerated ? "A {destPath}" : file.modified ?
                        file.srcPath === file.destPath ? "M {destPath}" : "M {srcPath} -> {destPath}" :
                        file.srcPath === file.destPath ? "C {destPath}" : "C {srcPath} -> {destPath}" :
                    file.isGenerated ? "A {destName}" : file.modified ?
                        file.srcName === file.destName ? "M {destName}" : "M {srcName} -> {destName}" :
                        file.srcName === file.destName ? "C {destName}" : "C {srcName} -> {destName}",
                file), LogLevel.progress);
        }
    }

    /**
     * 当文件清理后执行。
     * @param file 相关的文件。
     */
    onFileClean(file: BuildFile) {
        if (!this.trigger("fileclean", file)) return;
        if (!this._progressProcess) {
            this.log(this.time + this.format(this.fullPath ? "D {srcPath}" : "D {srcName}", file), LogLevel.progress);
        }
    }

    // #endregion

    // #region 清理

    /**
     * 清理项目。
     */
    clean() {

        // 开始清理。
        this.currentAction = BuildAction.clean;
        this.beginProgress();
        this.reset();

        // 全局模式并且目标文件夹是独立的，则直接清空文件夹。
        if (this.global && !containsDir(this.destPath, this.srcPath)) {
            this.progress(this.format("Cleaning '{destPath}'", this));
            IO.cleanDir(this.destPath, true);
            this.success("{time}Clean Success: '{destPath}'", this);
            this.endProgress();
            return;
        }

        // 由于有限定条件或目标文件夹和源文件夹在一起，不能直接直接删除目标文件夹。
        // 重新生成每个文件并执行清理。

        // 生成每个文件并清理。
        this.walkDir("", name => {
            this.getFile(name).clean();
        });

        // 清理成功后回调。
        this.success("{time}Clean Success! ({buildFileCount} file(s) cleaned)", this);
        this.endProgress();

    }

    // #endregion

    // #region 预览

    /**
     * 预览项目生成。
     */
    preview() {

        this.currentAction = BuildAction.preview;

        this.startTimer();
        this.info(this.basePath === this.destPath ? "{time}Preview '{basePath}'..." : "{time}Preview '{basePath}' -> '{buildPath}'...", this);
        this.reset();

        // 生成所有文件。
        this.walkDir("", name => {
            this.onFileSave(this.getFile(name));
            // TODO: 打印依赖树。
        });

        // 更新成功后回调。
        this.info("{time}Preview Done! (Elapsed: {elapsed}, File: {buildFileCount}, Error: {errorCount}, Warning: {warningCount})", this);

    }

    // #endregion

    // #region 生成

    /**
     * 判断或设置是否在生成前清理目标文件夹。
     * @default true
     */
    autoClean: boolean;

    /**
     * 使用当前的规则生成项目。
     */
    build() {

        // 设置标记。
        this.currentAction = BuildAction.build;

        // 生成开始。
        this.reset();
        if (this.global) {
            this.beginProgress();
            this.startTimer();
            this.info(this.srcPath === this.destPath ? "{time}Start Building '{srcPath}'..." : "{time}Start Building '{srcPath}' -> '{destPath}'...", this);
            if (this.autoClean !== false && !containsDir(this.destPath, this.srcPath)) {
                this.progress(this.format("Cleaning '{destPath}'", this));
                IO.cleanDir(this.destPath, true);
            }
        }
        this.trigger("prebuild");

        // 生成所有文件。
        this.walkDir("", name => {
            this.getFile(name).save();
        });

        // 结束生成。
        this.trigger("postbuild");
        if (this.global) {
            if (this.errorCount) {
                this.fatal("{time}Build Completed! ({elapsed} elapsed, {buildFileCount} file(s) saved, {errorCount} error(s) found)", this);
            } else {
                this.success("{time}Build Success! ({elapsed} elapsed, {buildFileCount} file(s) saved, without errors)", this);
            }
            this.endProgress();
        }
        this.trigger("build");

    }

    // #endregion

    // #region 监听

    /**
     * 获取当前监听的选项。
     */
    watchOptions = {

        /**
         * 获取或设置是否在初始化文件时保存文件。
         */
        initSave: true,

        /**
         * 获取或设置是否监听包含文件。
         */
        includes: true,

        /**
         * 删除文件时同时删除空的父文件夹。
         */
        deleteDir: true,

        /**
         * 获取或设置是否监听外部导入文件。
         */
        imported: true

    };

    /**
     * 存储当前使用的监听器。
     */
    private _watcher: Watcher;

    /**
     * 监听当前项目的改动并实时生成。
     * @return 返回对应的监听器。
     */
    watch() {
        return this._watcher || (this._watcher = new ((require("./watcher").Watcher) as typeof Watcher)(this));
    }

    /**
     * 当监听开始时回调。
     * @param watcher 当前的监听器。
     */
    onWatchStart(watcher: Watcher) {
        this.trigger("watchstart", watcher);
        this.info("{time}Start Watching '{srcPath}'...", this);
    }

    /**
     * 当监听开始时回调。
     * @param watcher 当前的监听器。
     */
    onWatchStop(watcher: Watcher) {
        this.trigger("watchstop", watcher);
        this.info("{time}Stop Watching '{srcPath}'.", this);
    }

    /**
     * 当监听错误时回调。
     * @param watcher 当前的监听器。
     * @param e 错误信息。
     */
    onWatchError(watcher: Watcher, e: NodeJS.ErrnoException) {
        this.trigger("watcherror", watcher, e);
        this.fatal("{time}Watching '{srcPath}' Error: {error}", { time: this.time, srcPath: this.srcPath, error: e });
    }

    /**
     * 当监听的文件发生改变准备重新生成时回调。
     * @param path 监听改变的原始路径。
     * @param event 监听改变的事件名。
     */
    onWatchReset(path: string, event) {
        this.log("");
    }

    /**
     * 当监听的文件发生改变时回调。
     * @param names 同时发生改变的文件名称列表。列表首项表示第一个改变的文件。
     */
    onWatchChange(names: string[]) {
        this.trigger("watchchange", names);
    }

    /**
     * 当监听的文件删除时回调。
     * @param names 同时发生改变的文件名称列表。列表首项表示第一个清理的文件。
     */
    onWatchDelete(names: string[]) {
        this.trigger("watchdelete", names);
    }

    // #endregion

    // #region 服务器

    /**
     * 获取或设置服务器相关选项。
     */
    serverOptions = {

        /**
         * 服务器的监听地址。其中，0.0.0.0 表示监听所有 IP 地址。端口设置为 0 表示随机端口。
         */
        url: "http://0.0.0.0:8080/",

        /**
         * 指示是否使用被动模式。
         */
        passive: false,

        /**
         * 服务器代理。
         */
        proxy: {} as { [path: string]: string },

        /**
         * 代理服务器使用的代理地址。
         */
        agent: null as HttpAgent | HttpsAgent

    };

    /**
     * 获取当前使用的服务器。
     */
    private _server: Server;

    /**
     * 启动开发服务器。
     * @returns 返回服务器对象。
     */
    startServer() {
        return this._server || (this._server = new ((require("./server").Server) as typeof Server)(this));
    }

    /**
     * 启动服务器并打开首页。服务器可以拦截所有请求并根据当前设置的规则处理后响应。
     * @param port 服务器的端口。 
     * @param url 服务器的地址。 
     * @param options 服务器的选项。 
     * @returns 返回服务器对象。
     */
    openServer() {
        var server = this.startServer();
        (require("child_process").exec as typeof exec)("start " + server.url, (error) => { error && this.fatal(error.toString()); });
        return server;
    }

    /**
     * 当服务器启动后执行。
     * @param server 当前相关的服务器。
     */
    onServerStart(server: Server) {
        this.trigger("serverstart", server);
        this.info("Server Running At '{url}'", server);
    }

    /**
     * 当服务器停止后执行。
     * @param server 当前相关的服务器。
     */
    onServerStop(server: Server) {
        this.trigger("serverstop", server);
        this.info("Server Stopped At '{url}'", server);
    }

    /**
     * 当服务器停止后执行。
     * @param server 当前相关的服务器。
     * @param e 当前的错误。
     */
    onServerError(server: Server, e: NodeJS.ErrnoException) {
        this.trigger("servererror", server, e);
        if (e.code === "EADDRINUSE" || e.code === "EACCES") {
            let url = require("url").parse(this.serverOptions.url);
            this.fatal(url.hostname !== "0.0.0.0" ? "Create Server Error: Port {port} of {address} is used by other programs." : "Create Server Error: Port {port} is used by other programs.", { port: url.port, address: url.hostname });
        } else {
            this.fatal("Server Error: {message}.",e);
        }
    }

    // #endregion

}

// #region 筛选器

/**
 * 表示一个名称筛选器。
 * @remark
 * 筛选器可以是：
 * - 通配符：表示一个名称。通配符如果以 / 开头，表示必须匹配跟目录，否则可以匹配子目录。支持以下通配符：
 * * - *：匹配任意字符
 * * - ?: 匹配一个字符
 * - 正则表达式
 * - 自定义函数：函数可以返回 true/false 表示是否匹配。
 */
export type Filter = string | RegExp | ((name: string) => boolean) | Array<string | RegExp | ((name: string) => boolean)>;

/**
 * 表示一个已编译的筛选器函数。
 */
export interface CompiledFilter {

    /**
     * 测试指定的名称是否匹配。
     * @param name 要测试的名称。
     * @returns 如果匹配则返回 @true，否则返回 @false。
     */
    (name: string): boolean;

    /**
     * 测试指定的名称是否匹配，并替换为新名称。
     * @param name 要测试的名称。
     * @param target 要替换的目标名称。其中 $0, $1... 会被替换为原通配符匹配的内容。
     * @returns 如果匹配则返回 @target，其中 $0, $1... 会被替换为原通配符匹配的内容，否则返回 @null。
     */
    (name: string, target: string): string;

    /**
     * 当前匹配器的内部参数列表。
     */
    args?: any[];

}

/**
 * 表示一个筛选器集合。
 */
export interface FilterSet extends Array<Filter> {

    /**
     * 获取或设置当前集合的编译版本。
     */
    compiled?: CompiledFilter;

}

/**
 * 编译指定的筛选器集合。
 * @param filters 匹配模式表达式列表。
 * @param matchAll 如果设为 @true，则名称必须完全匹配，否则允许局部匹配。
 * @param basePath 所有绝对路径转换的基路径。
 * @returns 返回已编译的筛选器函数。
 * @example compileFilters("*.ts")("a.ts") // 返回 true
 * @example compileFilters("*.ts")("a.ts", "$1.js") // 返回 "a.js"
 */
export function compileFilters(filters: FilterSet, matchAll?: boolean, basePath?: string) {
    let filterFuncBody = "";
    let args = [];

    // 解析每个筛选器。
    for (let i = 0, arr = filters; i < arr.length; i++) {
        let filter = arr[i] as any;

        // "*.sources*"
        if (typeof filter === "string") {

            // 加速 * 匹配。
            if (filter === "*" && !args.length) {
                return ((name: string, target: string) => target != null ? target.replace(/\$[01]/g, name) : true) as CompiledFilter;
            }

            // 解析绝对路径。
            filter = containsDir(basePath, filter) ? relative(basePath, filter) : Path.normalize(filter).replace(/\\/g, "/");

            // 如果存在前导 /，则一定匹配跟目录。
            let prefix: string;
            if (filter.charCodeAt(0) === 47/*/*/) {
                filter = filter.substr(1);
                prefix = "^";
            } else {
                prefix = matchAll ? "^" : "(?:^|\\/)";
            }

            // 如果存在后导 /，则一定匹配目录，不能匹配文件名。
            let postfix: string;
            if (filter.charCodeAt(filter.length - 1) !== 47 /*/*/) {
                postfix = "(?:\\/|$)";
            } else {
                postfix = "";
            }

            // 处理特殊字符。
            filter = new RegExp(prefix + filter.replace(/([-.+^${}()|\/\\])/g, "\\$1").replace(/\*/g, "(.*)").replace(/\?/g, "([^/])") + postfix, "i");
        }

        // /.../
        if (filter instanceof RegExp) {
            filterFuncBody += `if(target!=null?(_t=_args[${args.length}].exec(name)):(_t=_args[${args.length}].test(name)))return target!=null?target.replace(/${"\\$(\\d+)"}/g,function(_,i){return _t[i]}):true;`;
            args[args.length] = filter;
            continue;
        }

        // function(){ ... }
        if (typeof filter === "function") {
            filterFuncBody += `if(_args[${args.length}].call(this, name))return target!=null?target:true;`;
            args[args.length] = filter;
            continue;
        }

        // 数组
        if (Array.isArray(filter)) {
            arr = arr.concat(filter);
            continue;
        }

    }

    // 编译函数。
    let result = new Function("name", "target", `var _args=arguments.callee.args,_t;${filterFuncBody}return target!=null?null:false;`) as CompiledFilter;
    result.args = args;
    return result;
}

// #endregion

/**
 * 表示日志等级。
 */
export enum LogLevel {

    /**
     * 进度日志。
     */
    progress,

    /**
     * 普通日志。
     */
    log,

    /**
     * 信息日志。
     */
    info = 10,

    /**
     * 成功日志。
     */
    success,

    /**
     * 警告日志。
     */
    warning,

    /**
     * 错误日志。
     */
    error,

    /**
     * 致命错误日志。
     */
    fatal,

    /**
     * 无日志。
     */
    none = 255

}

/**
 * 表示生成器的支持行为。
 */
export enum BuildAction {

    /**
     * 其它操作。
     */
    other,

    /**
     * 生成。
     */
    build,

    /**
     * 监听（增量生成）。
     */
    watch,

    /**
     * 服务器（实时生成）。
     */
    server,

    /**
     * 清理。
     */
    clean,

    /**
     * 预览。
     */
    preview

}

/**
 * 判断一个父文件夹是否包含指定子文件夹。
 * @param parent 父文件夹路径。
 * @param child 子文件夹路径。
 * @returns 如果包含返回 @true。
 */
export function containsDir(parent: string, child: string) {
    if (parent.length > child.length) {
        return false;
    }
    return child.toLowerCase().replace(/\\/g, "/").startsWith(parent.toLowerCase().replace(/\\/g, "/"));
}

/**
 * 计算相对路径。
 * @param from 基路径。
 * @param to 目标路径。
 */
export function relative(from: string, to: string) {
    return Path.relative(from, to).replace(/\\/g, "/");
}

/**
 * 将数字转为字符串，并自动补齐 '0'。
 * @param value 要补齐的字符串。
 */
export function padZero(value: number) {
    return value < 10 ? "0" + value : value.toString();
}
