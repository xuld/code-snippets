﻿/**
 * @fileOverview 监听器。
 */

/// <reference path="../.vscode/typings/tpack/chokidar.d.ts" />

import * as FS from "fs";

import {FSWatcher, WatchOptions} from "chokidar";

import {Builder, BuildAction, containsDir} from "./builder";
import {BuildFile} from "./buildFile";

/**
 * 表示一个监听器。
 */
export class Watcher extends FSWatcher {

    /**
     * 获取当前监听器所属的生成器。
     */
    builder: Builder;

    /**
     * 判断当前监听器是否已准备就绪。
     */
    isReady = false;

    /**
     * 当开始监听时执行。
     */
    protected onStart() {
        this.builder.onWatchStart(this);
    }

    /**
     * 当结束监听时执行。
     */
    protected onStop() {
        this.builder.onWatchStop(this);
    }

    /**
     * 当监听错误时执行。
     * @param e 原始错误信息。
     */
    protected onError(e: NodeJS.ErrnoException) {
        if (e.code !== "EPERM") {
            this.builder.onWatchError(this, e);
        }
    }

    /**
     * 当文件被添加到监视列表执行。
     * @param path 更新的路径。
     */
    protected onInit(path: string) {
        let builder = this.builder;
        let file = builder.getFile(builder.toName(path));
        if (builder.watchOptions.initSave) {
            file.save();
        }
        this._watchImported(file);
    }

    /**
     * 当文件新建或更新后执行。
     * @param path 更新的路径。
     */
    protected onChange(path: string) {

        // 重置以生成。
        this.builder.reset();
        this.builder.onWatchReset(path, "change");

        // 对于外部路径，只需更新项目里相关文件。
        if (!containsDir(this.builder.srcPath, path)) {
            let updated = [];
            if (this.builder.watchOptions.includes) {
                this._updateIncludes(path, updated);
            }
            if (updated.length) {
                this.builder.onWatchChange(updated);
            } else {
                // 如果不存在关联的文件则结束监听。
                this.unwatch(path);
                let p = this._imported.indexOf(path);
                if (p >= 0) this._imported.splice(p, 1);
            }
            return;
        }

        // 更新主文件。
        let file = this.builder.getFile(this.builder.toName(path));
        file.save();
        this._watchImported(file);

        // 更新包含当前文件的文件。
        let updated = [file.srcName];
        if (this.builder.watchOptions.includes) {
            this._updateIncludes(path, updated);
        }

        // 通知生成器。
        this.builder.onWatchChange(updated);
    }

    /**
     * 当文件删除后执行。
     * @param path 更新的路径。
     */
    protected onDelete(path: string) {

        // 重置以生成。
        this.builder.reset();
        this.builder.onWatchReset(path, "delete");

        // 清理主文件。
        let file = this.builder.createFile(this.builder.toName(path), "");
        this.builder.processFile(file);
        file.clean(this.builder.watchOptions.deleteDir);

        // 更新包含当前文件的文件。
        let updated = [file.srcName];
        if (this.builder.watchOptions.includes) {
            this._updateIncludes(path, updated);
        }

        // 通知生成器。
        this.builder.onWatchDelete(updated);
    }

    /**
     * 更新包含指定路径的所有文件。
     * @param path 要检查的被包含的路径。
     * @param updated 存放已更新的文件路径本身。
     */
    private _updateIncludes(path: string, updated: string[]) {
        let builder = this.builder;
        for (let name in builder.files) {
            let file = builder.files[name];
            if (file.includes && file.includes.indexOf(path) >= 0 && updated.indexOf(file.srcName) < 0) {
                updated.push(file.srcName);
                let newFile = builder.getFile(file.srcName);
                newFile.save();
                this._updateIncludes(newFile.srcPath, updated);
                this._watchImported(newFile);
            }
        }
    }

    /**
     * 存储所有正在监视的外部导入文件路径。
     */
    private _imported: string[] = [];

    /**
     * 当一个文件更新后监听其导入项。
     * @param file 被更新的文件。
     */
    private _watchImported(file: BuildFile) {
        if (!file.includes || !this.builder.watchOptions.includes || !this.builder.watchOptions.imported) return;
        for (let i = 0; i < file.includes.length; i++) {
            let path = file.includes[i];
            if (!containsDir(this.builder.srcPath, path) && this._imported.indexOf(path) < 0) {
                this._imported.push(path);
                this.add(path);
            }
        }
    }

    /**
     * 初始化新的监听器。
     * @param builder 当前监听器所属的生成器。
     */
    constructor(builder: Builder) {
        super((
            (builder.watchOptions as WatchOptions).ignoreInitial = !builder.watchOptions.includes,
            (builder.watchOptions as WatchOptions)
        ));

        this.builder = builder;

        // 设置过滤器。
        this._isIgnored = function (path: string, stat: FS.Stats) {
            path = builder.toName(path);

            // 忽略已被忽略的路径。
            if (builder.ignored(path)) {
                return true;
            }

            // 不忽略文件夹。
            if (!stat || stat.isDirectory()) {
                return false;
            }

            // 只处理已被筛选的路径。
            return !builder.filtered(path);
        };

        // 开始监听。
        this.start();

    }

    /**
     * 开始监听。
     */
    start() {

        // 设置操作。如果需要更新依赖项，则先生存项目以获取依赖关系。
        if (this.builder.watchOptions.includes) {
            this.builder.currentAction = BuildAction.build;
            this.builder.beginProgress();
        } else {
            this.builder.currentAction = BuildAction.watch;
        }

        this.on("ready", () => {
            this.isReady = true;
            if (this.builder.watchOptions.includes) {
                this.builder.endProgress();
                this.builder.currentAction = BuildAction.watch;
            }
            this.onStart();
        });

        this.on("add", (path: string) => {
            if (this.isReady) {
                this.onChange(path);
            } else {
                this.onInit(path);
            }
        });

        this.on("change", (path: string) => { this.onChange(path); });

        this.on("unlink", (path: string) => { this.onDelete(path); });

        this.on("error", (e: NodeJS.ErrnoException) => { this.onError(e); });

        this.add(this.builder.srcPath);
    }

    /**
     * 关闭当前监听器。
     */
    close() {
        this.isReady = false;
        if (!this.closed) {
            super.close();
            this.onStop();
        }
        return this;
    }

}