﻿/**
 * @fileOverview TPack 对外接口。
 */

import * as Path from "path";
import {execSync, ExecOptionsWithStringEncoding} from "child_process";

import * as IO from "tutils/node/io";
import {Builder, BuildAction, LogLevel} from "./builder";

import {BuildRule} from "./buildRule";
import {BuildFile} from "./buildFile";

/**
 * 提供生成器对外接口。
 */
class TPackBuilder extends Builder {

    // #region 对外接口

    /**
     * 生成器。
     */
    Builder = Builder;

    /**
     * 日志等级。
     */
    LogLevel = LogLevel;

    /**
     * 生成操作。
     */
    BuildAction = BuildAction;

    /**
     * 获取当前构建器的版本。
     */
    get version() { return require("../package.json").version; }

    /**
     * 尝试载入指定的插件。
     * @param name 要载入的插件名。
     * @returns 返回插件对应的处理器函数。
     */
    plugin(name: string) {
        let result: (file: BuildFile, options) => void;
        try {
            result = require(name);
        } catch (e) {
            result = file => {
                file.error("PluginLoadError", e, null, null, null, null, null, null, this.format("Run 'npm install {name} -g' to reinstall it.", { name }));
            };
        }
        result["plugin"] = name;
        return result;
    }

    /**
     * 载入忽略文件（如 .gitignore）。
     * @param path 要载入的文件路径。
     */
    loadIgnore(path: string) {
        IO.readLines(path).forEach(content => {
            content = content.trim();
            if (content && !/^#/.test(content)) {
                this.ignore(content);
            }
        });
    }

    /**
     * 执行一个命令行程序。
     * @param command 要执行的命令行。命令行参数以逗号隔开。
     * @param args 执行相关参数。
     */
    exec(command: string, args: ExecOptionsWithStringEncoding) {
        this.progress(command);
        let result = (require("child_process").execSync as typeof execSync)(command, args).toString();
        this.log(result);
    }

    // #endregion

    // #region 任务系统

    /**
     * 获取所有任务列表。
     */
    tasks: { [taskName: string]: string | ((taskOptions?: Object) => void) } = {
        __proto__: null,
        default: function() {}
    };

    /**
     * 执行已定义的任务。
     * @param taskName 要执行的任务名。
     * @param taskOptions 执行任务使用的参数。
     * @example tpack.task("hello", {})  // 执行任务 hello
     */
    task(taskName: string, taskOptions?: Object): any;

    /**
     * 定义任务的别名。
     * @param taskName 要定义的任务名。多个任务名用空格隔开。
     * @param aliasName 定义原始任务名。
     * @returns 返回任务函数本身。
     * @example tpack.task("h", "hello")  // 定义任务 h, 同 hello
     */
    task(taskName: string, aliasName: string): string;

    /**
     * 定义一个任务。
     * @param taskName 要定义的任务名。多个任务名用空格隔开。
     * @param taskAction 任务函数本身。
     * @returns 返回任务函数本身。
     * @example tpack.task("hello", function(){ })  // 定义任务 hello
     */
    task(taskName: string, taskAction: (options: any) => void): (options: any) => void;

    /**
     * 定义或执行一个任务。
     * @param taskName 要定义的任务名。多个任务名用空格隔开。
     * @param taskAction 任务函数本身。
     * @returns 返回任务函数本身。
     * @example tpack.task("hello", function(){ })  // 定义任务 hello
     */
    task(taskName: string, taskAction?: Object | string | ((options?: Object) => void)) {

        let tasks = this.tasks;

        // tpack.task("hello", "") 定义任务。
        // tpack.task("hello", function(){}) 定义任务。
        if (typeof taskAction === "string" || typeof taskAction === "function") {
            if (/[\s,]/.test(taskName)) {
                let t = taskName.split(/[\s,]+/);
                taskName = t[0];
                for (let i = 1; i < t.length; i++) {
                    tasks[t[i]] = taskName;
                }
            }
            return tasks[taskName] = taskAction as string | ((options?: Object) => void);
        }

        // 执行任务别名。
        while (typeof tasks[taskName] === "string") {
            taskName = tasks[taskName] as string;
        }

        // 执行任务。
        if (typeof tasks[taskName] === "function") {
            return (tasks[taskName] as ((options?: Object) => void)).call(this, taskAction == null ? {} : taskAction);
        }

    }

    // #endregion

    // #region 命令行支持

    /**
     * 获取或设置当前使用的配置文件。
     */
    configPath: string;

    /**
     * 载入配置文件。
     * @param path 指定配置文件地址。
     * @param 返回配置文件的导出对象。
     */
    loadConfig(path: string) {
        this.basePath = Path.dirname(path);
        this.updateSystemIgnore(this.configPath, path);
        this.configPath = path;
        return require(path);
    }

    // #endregion

}

export = new TPackBuilder();
