﻿/**
 * @fileOverview 规则。
 */

import * as Path from "path";

import {Builder, Filter, FilterSet, compileFilters, BuildAction} from "./builder";
import {BuildFile} from "./buildFile";

/**
 * 表示默认的空配置。
 */
const EMPTY_OPTIONS = Object.freeze({});

/**
 * 表示一条生成规则。
 * @remark
 * 一条规则可以指定若干处理器。
 * 所有匹配当前规则的文件都会被预设的处理器处理。
 */
export class BuildRule {

    // #region 筛选和忽略

    /**
     * 获取当前规则所属的生成器。
     */
    builder: Builder;

    /**
     * 获取或设置当前规则的筛选列表。列表可以包含通配符、正则表达式、自定义函数或以上组合的列表。
     */
    filters: FilterSet;

    /**
     * 初始化新的规则。
     * @param builder 所属的生成器。
     * @param filters 筛选列表。列表可以包含通配符、正则表达式、自定义函数或以上组合的列表。
     */
    constructor(builder: Builder, filters: FilterSet) {
        this.builder = builder;
        this.filters = filters;
    }

    /**
     * 获取或设置当前规则的忽略列表。列表可以包含通配符、正则表达式、自定义函数或以上组合的列表。
     */
    ignores: FilterSet;

    /**
     * 添加忽略的文件或文件夹。
     * @param filters 要忽略的文件或文件夹名称。可以使用通配符、正则表达式、自定义函数或以上组合的列表。
     */
    ignore(...filters: Filter[]): this;

    /**
     * 添加忽略的文件或文件夹。
     * @param filters 要忽略的文件或文件夹名称。可以使用通配符、正则表达式、自定义函数或以上组合的列表。
     */
    ignore() {
        if (this.ignores) {
            this.ignores.push.apply(this.ignores, arguments);
            delete this.ignores.compiled;
        } else {
            this.ignores = Array.prototype.slice.call(arguments);
        }
        return this;
    }

    /**
     * 判断指定的文件或文件夹是否被忽略。
     * @param name 要判断的文件或文件夹名称。
     * @returns 如果指定的文件或文件夹名称已被忽略则返回 @true，否则返回 @false。
     */
    ignored(name: string) {
        return this.ignores && this.ignores.length ? (this.ignores.compiled || (this.ignores.compiled = compileFilters(this.ignores, false, this.builder.srcPath))).call(this, name) as boolean : false;
    }

    /**
     * 测试指定的名称是否匹配当前规则。
     * @param name 要测试的名称。
     * @returns 如果匹配则返回 @true，否则返回 @false。
     */
    match(name: string): boolean;

    /**
     * 测试指定的名称是否匹配当前规则，并替换为新名称。
     * @param name 要测试的名称。
     * @param target 要替换的目标名称。其中 $0, $1... 会被替换为原通配符匹配的内容。
     * @returns 如果匹配则返回 @target，其中 $0, $1... 会被替换为原通配符匹配的内容，否则返回 @null。
     */
    match(name: string, target: string): string;

    /**
     * 测试指定的名称是否匹配当前规则，并替换为新名称。
     * @param name 要测试的名称。
     * @param target 要替换的目标名称。其中 $0, $1... 会被替换为原通配符匹配的内容。
     * @returns 如果匹配则返回 @target，其中 $0, $1... 会被替换为原通配符匹配的内容，否则返回 @null。
     */
    match(name: string, target?: string) {
        return this.ignored(name) ?
            target != null ? null : false :
            (this.filters.compiled || (this.filters.compiled = compileFilters(this.filters, true, this.builder.srcPath))).call(this, name, target);
    }

    /**
     * 遍历当前规则匹配的所有文件。
     * @param callback 遍历函数。
     */
    walk(callback: (name: string) => void) {
        this.builder.walkDir("", name => {
            if (this.match(name)) {
                callback.call(this, name);
            }
        });
    }

    // #endregion

    // #region 处理器

    /**
     * 获取当前规则所有的处理器。
     */
    processors: ({ processor: Processor, options: Object })[] = [];

    /**
     * 为当前规则添加一个处理器。
     * @param processor 要添加的处理器。
     * @param options 传递给处理器的只读配置对象。
     */
    pipe(processor: Processor, options?: Object) {
        let rule = this as BuildRule;

        // 聚合处理器：合并匹配的所有文件。
        if (processor.group) {

            // 创建聚合目标规则。
            rule = new GroupBuildRule(this.builder, this.filters);

            // 添加原规则的处理器：任一文件处理时，都将驱动执行聚合规则。
            this.pipe(function Group(file) {
                (rule as GroupBuildRule).run(file);
            });

        }

        // 加入处理器。
        rule.processors.push({
            processor: processor,
            options: options == null ? EMPTY_OPTIONS : Object.freeze(options)
        });

        return rule;
    }

    /**
     * 清空当前规则的所有处理器。
     */
    clear() {
        this.processors.length = 0;
        return this;
    }

    // #endregion

    // #region 预设处理器

    /**
     * 添加一个设置目标路径的处理器。
     * @param name 要设置的目标路径。目标路径可以是字符串（其中 $N 表示匹配的模式)。
     */
    dest(name?: string) {

        // 忽略空目标。
        if (!name) return this;

        // 删除前导 / 。
        if (name.charCodeAt(0) === 47/*/*/) name = name.substr(1);

        // 如果 @name 以 / 结尾表示目标是文件夹，则追加文件名。
        if (name.charCodeAt(name.length - 1) === 47/*/*/) {
            name += typeof this.filters[0] === "string" ? (this.filters[0] as string).indexOf("*.") >= 0 ? "$1$EXT" : (this.filters[0] as string).indexOf('*') >= 0 ? "$1" : "$0" : "$0";
        }

        // 添加重命名函数。
        return this.pipe(function Dest(file) {
            let targetName = file.format(file.rule.match(file.initalName, name) || name);
            file.name = targetName.charCodeAt(0) === 46/*.*/ ? Path.join(file.name, targetName).replace(/\\/g, "/") : targetName;
        }) as this;

    }

    /**
     * 添加一个设置扩展名的处理器。
     * @param extension 要设置的扩展名。
     */
    extension(extension: string) {
        return this.pipe(function Extension(file) {
            file.extension = extension;
        });
    }

    /**
     * 添加一个复制当前文件的处理器。
     */
    copy() {
        let rule = new GroupBuildRule(this.builder, this.filters);
        this.pipe(function Copy(file) {
            let newFile = rule.file = this.createFile(file.name, file.data);
            this.processFileWithRule(newFile, rule);
            file.relate(newFile);
        });
        return rule as BuildRule;
    }

    /**
     * 添加一个保存文件的处理器。
     */
    save() { return this.pipe(function Save(file) { file.save(); }) as this; }

    /**
     * 添加一个清理文件的处理器。
     */
    clean() { return this.pipe(function Clean(file) { file.clean(); }) as this; }

    /**
     * 添加一个在当前文件指定位置插入内容的处理器。
     * @param index 要插入的位置。
     * @param value 要插入的内容。
     * @param source 插入内容的来源。
     * @param line 插入内容的在源文件的行号。
     * @param column 插入内容的在源文件的列号。
     */
    insert(index: number, value: string, source?: string | BuildFile, line?: number, column?: number) {
        return this.pipe(function Insert(file) { file.insert(index, value, source, line, column); }) as this;
    }

    /**
     * 添加一个在文件末尾插入内容的处理器。
     * @param value 要插入的内容。
     * @param source 插入内容的来源。
     * @param line 插入内容的在源文件的行号。
     * @param column 插入内容的在源文件的列号。
     */
    append(value: string, source?: string | BuildFile, line?: number, column?: number) {
        return this.pipe(function Append(file) { file.append(value, source, line, column); }) as this;
    }

    /**
     * 添加一个删除文指定位置区间内容的处理器。
     * @param startIndex 要删除的起始位置。
     * @param endIndex 要删除的结束位置（不含位置本身）。
     */
    remove(startIndex: number, endIndex?: number) {
        return this.pipe(function Remove(file) { file.remove(startIndex, endIndex); }) as this;
    }

    /**
     * 添加一个替换文件内容的处理器。
     * @param searchValue 要替换的源。
     * @param replaceValue 替换的目标。
     * @param source 替换内容的来源。
     * @param line 替换内容的在源文件的行号。
     * @param column 替换内容的在源文件的列号。
     */
    replace(searchValue: string | RegExp, replaceValue: string | ((match: string, ...rest: string[]) => string), source?: string | BuildFile, line?: number, column?: number) {
        return this.pipe(function Replace(file) { file.replace(searchValue, replaceValue, source, line, column); }) as this;
    }

    // #endregion

}

/**
 * 表示一条聚合规则。
 * @remark
 * 普通规则一次只能处理一个文件。
 * 聚合规则可以一次处理多个文件，并最后输出一个文件。
 * 在文件合并或者代码打包编译时应使用聚合规则。
 */
export class GroupBuildRule extends BuildRule {

    /**
     * 获取或设置当前规则生成的最终文件。
     */
    file: BuildFile;

    /**
     * 执行当前聚合规则。
     * @param parent 引发执行当前规则的入口文件。
     * @return 返回生成的最终文件。
     */
    run(parent: BuildFile) {
        let file = this.file;
        if (!file || file.buildVersion < this.builder.buildVersion) {
            this.file = file = this.builder.createFile();
            file.buildVersion = this.builder.buildVersion;
            this.builder.processFileWithRule(file, this);
        }
        if (parent) {
            parent.relate(file);
        }
        return file;
    }

}

/**
 * 表示一个处理器。
 */
export interface Processor {

    /**
     * 执行当前处理器。
     * @param file 要处理的文件。
     * @param options 传递给处理器的只读配置对象。
     */
    (file: BuildFile, options: Object): void;

    /**
     * 获取当前处理器的名字。
     */
    name?: string;

    /**
     * 获取当前处理器的插件。
     */
    plugin?: string;

    /**
     * 判断当前处理器是否是聚合任务。
     */
    group?: boolean;

}
