﻿/**
 * @fileOverview 控制台进度条子进程。
 */
/// <reference path="../.vscode/typings/node/node.d.ts" />

// 获取控制台长度。
let windowWidth = process.stdout["getWindowSize"]()[0] - 3; // 减去进度字符本身宽度。
process.stdout.on('resize', () => { windowWidth = process.stdout["getWindowSize"]()[0] - 3 });

// 当前进度样式。
let stepStyle = 0;

/**
 * 打印一行进度。
 */
function printLine() {
    clearLine();
    
    // 打印进度字符。
    let progressChar;
    switch (++stepStyle) {
        case 1:
            progressChar = '- ';
            break;
        case 2:
            progressChar = '\\ ';
            break;
        case 3:
            progressChar = '| ';
            break;
        default:
            progressChar = '/ ';
            stepStyle = 0;
            break;
    }

    process.stdout.write(progressChar + (currentMessage.length > windowWidth ? currentMessage.substr(0, windowWidth - 3) + '...' : currentMessage));
}

/**
 * 清空当前行。
 */
function clearLine() {
    let stdout = process.stdout as any;
    stdout.cursorTo(0);
    stdout.clearScreenDown();
}

/**
 * 当前要显示的进度条文案。
 */
var currentMessage: string = "";

/**
 * 当前的进度条计时器。
 */
var timer = setInterval(printLine, 100);

/**
 * 驱动进度条显示。
 * send("...") 显示日志。
 * send(true) 开始显示日志。
 * send(false) 停止显示日志。
 */
process.on('message', message => {
    if (message.command) {
        clearLine();
        clearInterval(timer);
        if (message.command === 1) {
            process.exit();
        } else {
            (message.command === 2 ? process.stdout : process.stderr).write(message.buffer, message.encoding, () => {
                timer = setInterval(printLine, 100);
            });
        }
        return;
    }

    currentMessage = message as string;
});
