﻿function a(c) {
    var b = undefined;
    return b;
