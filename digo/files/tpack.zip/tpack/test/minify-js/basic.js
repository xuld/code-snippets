﻿function a(c) {
    var b = undefined;
    return b;
}

if (DEBUG) {
    console.log("debug stuff");
}