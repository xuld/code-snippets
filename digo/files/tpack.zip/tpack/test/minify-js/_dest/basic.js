function a(n) {
    var e = undefined;
    return e;
}

if (DEBUG) {
    console.log("debug stuff");
}