﻿// 载入 tpack 包。
var tpack = require("tpack");
tpack.lang = "zh-cn";
tpack.sourceMap = true;

// 设置全局忽略的路径。
tpack.loadIgnore(".gitignore");
tpack.ignore(".*", "_*", "$*", "*~");

tpack.task("pre-post", function () {
    tpack.on("prebuild", function () {
        tpack.log("生成开始：{0}", new Date());
    });
    tpack.on("postbuild", function () {
        tpack.log("生成结束：{0}", new Date());
        tpack.createFile("NOTE.txt", "此项目是从 " + tpack.srcPath + " 生成的，不要修改！生成时间：" + new Date()).save();
    });
    tpack.build();
});

tpack.task("basic", function () {
    tpack.src("basic/*").pipe(function (file) {
        file.append("/*哈哈*/");
    }).dest("basic/_dest/");
});

tpack.task("clean", function () {
    tpack.src("basic/*").pipe(function (file) {
        file.append("/*哈哈*/");
    }).dest("basic/_dest/");
    tpack.clean();
});

tpack.task("exec", function () {
    tpack.exec("git add -A");
    tpack.exec("git commit -m '自动提交'");
});

tpack.task("ignore", function () {
    tpack.ignore("abc1");
    tpack.ignore("abc2/");
    tpack.ignore("/abc3");
    tpack.ignore("/abc4/");
    tpack.ignore(/^\d+$/);
    tpack.ignore(function (a) {
        return a.startsWith("ddd");
    });

    var list = {
        "abc1": true,
        "abc1/def5": true,
        "abc5/abc1": true,

        "abc2": true,
        "abc2/def5": true,
        "abc5/abc2": true,

        "abc3": true,
        "abc3/def5": true,
        "abc5/abc3": false,

        "abc4": true,
        "abc4/def5": true,
        "abc5/abc4": false,

        "ddd": true,
        "dddddd": true

    };


    for (var p in list) {
        console.log(p, "=>", tpack.ignored(p), " = ", list[p]);
    }

});

tpack.task("server", function () {
    tpack.serverOptions.proxy = {
        "baidu/*": "http://www.baidu.com/"
        // "baidu/*": "http://localhost:5389/"
    };
    tpack.serverOptions.passive = true;
    tpack.src("*").pipe(function (file) {
        file.append("/*哈哈*/");
    });
    tpack.startServer();
});

tpack.task("compile-coffeescript", function () {
    tpack.src("compile-coffeescript/*.coffee").pipe(require("tpack-coffee-script")).dest("compile-coffeescript/_dest/");
});

tpack.task("compile-es6", function () {
    tpack.src("compile-es6/*.es").pipe(require("tpack-babel")).dest("compile-es6/_dest/");
});

tpack.task("compile-less", function () {
    tpack.src("compile-less/*.less").pipe(tpack.plugin("tpack-less")).dest("compile-less/_dest/");
});

tpack.task("compile-markdown", function () {
    tpack.src("compile-markdown/*.md", "compile-markdown/*.markdown").pipe(require("tpack-node-markdown")).dest("compile-markdown/_dest/");
});

tpack.task("compile-sass", function () {
    tpack.src("compile-sass/*.scss", "compile-sass/*.sass").pipe(require("tpack-node-sass")).dest("compile-sass/_dest/");
});

tpack.task("compile-typescript", function () {
    tpack.src("compile-typescript/*.ts", "compile-typescript/*.tsx").pipe(require("tpack-typescript")).dest("compile-typescript/_dest/");
});

tpack.task("concat", function () {
    tpack.src("concat/*.js").pipe(require("tpack-concat")).dest("concat/_dest/concat.js");
});

tpack.task("minify-css", function () {
    tpack.src("minify-css/*.css").pipe(require("tpack-clean-css")).dest("minify-css/_dest/");
});

tpack.task("minify-html", function () {
    tpack.src("minify-html/*.html").pipe(require("tpack-html-minifier")).dest("minify-html/_dest/");
});

tpack.task("minify-js", function () {
    tpack.src("minify-js/*.js").pipe(require("tpack-uglify-js"),
    {
        compress: false,
        output: {
            beautify: true
        }
    }).dest("minify-js/_dest/");
});

tpack.task("modular", function () {
    var options = {

        resolve: {
            alias: {
                "~/": ""
            }
        },

        module: {
            "*.js": {
                defines: {
                    V: "ValueOfMain"
                },
                require: {
                    "./$1.css": true,
                    "./common.js": false
                }
            }
        },

        defines: {
            T: true,
            F: false,
            V: "Value"
        },

        regions: {
            F: false
        },

        //// require 未包含扩展名时，尝试自动追加的扩展名。
        //extensions: ['.json', '.jsx', '.es', '.es6', '.coffee', '.js', '.scss', '.less', '.css'],

        //// require 全局搜索路径。如果未指定则不启用全局搜索功能，所有路径均为相对路径。
        //paths: ["libs"],

        //// 将包含以下扩展名的文件自动导出到外部文件，而非放入当前文件。
        //exports: {
        //    // 导出 JS 中依赖的 CSS 文件到同名 CSS 文件。
        //    'css': '../styles/$1.css',
        //    // 导出 JS 中依赖的 CSS文件到同名 
        //    'resources': '../images/',
        //},

        //// 自动排除以下文件。
        //exclude: ["assets/common.js"]
    };

    tpack.src("modular/*").pipe(require("tpack-modular"), options).dest("modular/_dest/");
});

tpack.task("postcss", function () {
    tpack.src("postcss/*.css").pipe(tpack.plugin("tpack-postcss"), {
        processors: [
            require("autoprefixer")({
                browsers: [">1%"]
            })
        ]
    }).dest("postcss/_dest");
});