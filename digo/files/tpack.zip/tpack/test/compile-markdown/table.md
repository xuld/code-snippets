A | B | C
===========
D | E | F
D | E | F