﻿# 这里放 page2 页面本身的 js
a = 1
if a > 1
    a = 2 a # a is error
/* compile-coffeescript/error.coffee(4,11): [CoffeeSyntaxError]unexpected identifier */