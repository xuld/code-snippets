(function() {
  var a;

  a = 1;

  if (a > 1) {
    a = 2;
  }

}).call(this);
