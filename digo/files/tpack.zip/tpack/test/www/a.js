var a = [];
for(var i = 10000; i--;){
	a .push((function(i){
		return i;
	})(i))
}


console.log(22);
setTimeout(function(){
	
}, 30000);