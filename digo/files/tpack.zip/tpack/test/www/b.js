fs = require("fs");
fs.readFile('D:\\技术\\Node\\node_modules\\tpack\\test\\sample\\tpack.config.js', "utf-8", (a, b)=>{
    console.log(b);
})

setTimeout(function(){console.log(23213);}, 2000)