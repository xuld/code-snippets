var t = require("../../lib/index");
t.basePath = "src";
t.src("*.coffee").pipe(t.plugin("tpack-coffee-script"));
t.src("*.less").pipe(t.plugin("tpack-less"));
