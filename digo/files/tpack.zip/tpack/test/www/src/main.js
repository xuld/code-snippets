(function() {
  var a;

  a = 1;

}).call(this);
