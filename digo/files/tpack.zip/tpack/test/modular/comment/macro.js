﻿// #if V
F
// #endif

// #if T || F
T
// #endif

// #if F && F
F
// #endif

// #if F || (T && T)
T
// #endif