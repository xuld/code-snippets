﻿// #require ./b.js
b.a