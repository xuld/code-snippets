﻿
// #if T
T
// #else
F
// #endif

// #if F
F
// #else
T
// #endif
