﻿// #require ./require/a.js
// #require ./require/b.js
b.c