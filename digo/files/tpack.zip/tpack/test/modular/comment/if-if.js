﻿
// #if T

    // #if T
    T
    // #endif

    // #if F
    F
    // #elif T

        // #if F
        F
        // #else
        T
        // #endif

    // #endif

// #endif


// #if F

F