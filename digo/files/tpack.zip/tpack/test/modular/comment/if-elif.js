﻿// #if T
T
// #elif T
F
// #elif F
F
// #else
F
// #endif


// #if F
F
// #elif T
T
// #elif F
F
// #else
F
// #endif

// #if F
F
// #elif F
F
// #elif F
F
// #else
T
// #endif


// #if F
F
// #elif F
F
// #elif F
F
// #endif