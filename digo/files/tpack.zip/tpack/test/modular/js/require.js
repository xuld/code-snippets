﻿var a = require("./require/c.js");
module.exports = function () {
    a();
    alert("b");
};