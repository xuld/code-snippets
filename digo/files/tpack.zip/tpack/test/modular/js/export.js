module.exports = function () {
    alert("a");
};