﻿exports.func = function() {
    alert("c");
};