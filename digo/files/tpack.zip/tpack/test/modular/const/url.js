﻿var a = $URL("include/a.js")

$URL("include/a.js?$INLINE")

$URL("include/a.js?t=$MD5")
