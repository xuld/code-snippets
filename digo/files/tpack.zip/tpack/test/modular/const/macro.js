﻿var T = $MACRO("T")
$MACRO("F")
$MACRO("V")