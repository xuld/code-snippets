﻿__tpack__.define("b.js", function (require, exports, module) {
    module.exports = "b";
});