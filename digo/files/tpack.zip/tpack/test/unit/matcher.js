var assert = require("assert");
var tpack = require('../../lib/index');
var TestCases = {
    basePath: function () {
        tpack.basePath = "D:/root";
        tpack.srcPath = "src";
        assert.equal(tpack.srcPath, "D:\\root\\src\\");
    },
    ignore: function () {
        tpack.ignore("a", "*.b");
        tpack.ignore("c/c.*", "/d/*");
        assert.ok(tpack.ignored("a"));
        assert.ok(tpack.ignored("a.b"));
        assert.ok(!tpack.ignored("c/abc"));
        assert.ok(tpack.ignored("a/c/c.txt"));
        assert.ok(tpack.ignored("c/c.txt"));
        assert.ok(tpack.ignored("d/c.txt"));
        assert.ok(!tpack.ignored("r/d/c.txt"));
    }
};
for (var t in TestCases) {
    TestCases[t]();
}
//# sourceMappingURL=matcher.js.map