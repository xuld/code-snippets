﻿alert(1); 
﻿alert(2);