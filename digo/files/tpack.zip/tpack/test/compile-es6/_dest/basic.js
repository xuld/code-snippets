"use strict";

require("ddasd");

var a = function a(d) {};

var ddd = React.createElement(
	"div",
	null,
	React.createElement("a", null)
);