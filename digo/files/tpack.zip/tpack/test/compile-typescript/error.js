var c = ; // Missing {}
