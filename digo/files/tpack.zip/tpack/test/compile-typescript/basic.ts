var a = (d: string) => {};
import "AA";