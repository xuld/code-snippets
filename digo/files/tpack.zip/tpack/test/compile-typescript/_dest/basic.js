var a = function (d) { };
require("AA");
/*# sourceMappingURL=basic.js.map *///# sourceMappingURL=basic.js.map