var a = 2;
var b = <div class="a">
        {a + 1}
    </div>;
/*# sourceMappingURL=react.js.map *///# sourceMappingURL=react.js.map