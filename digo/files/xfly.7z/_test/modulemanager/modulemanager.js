


var ModuleManager = require("../../node/modulemanager/server/modulemanager.js");



ModuleManager.createModule('dom/base2/aaa/asdasd', 'js', 'DOM 操作底层');



ModuleManager.updateModuleInfo('/examples/dom/base.html', '啊啊啊啊', { status: 'obsolete', support: '' });


//var list = ModuleManager.getModuleList('src'); console.log(list);
