﻿//#include ui/container/dialog
//#include ajax/json
//#define compress true
//#define path apps/data/buildfiles/_test.js
//#define js ../build/_test.js
//#define css ../build/_test.css
//#define assets ../build/images
//#define prependComments /*********************************************************\
//# * This file is created by a tool at {time}\
//# ********************************************************/\
//#\
//#{modules}
//#define prependModuleComments /*********************************************************\
//# * {module}\
//# ********************************************************/