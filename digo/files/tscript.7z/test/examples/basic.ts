export function a() {

}

export var c = 1;

export function b() {
    a();
    c
}