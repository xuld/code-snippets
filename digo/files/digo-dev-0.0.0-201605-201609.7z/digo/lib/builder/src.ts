/**
 * @fileOverview 查找文件
 * @author xuld <xuld@vip.qq.com>
 */
import { Matcher, Pattern, getGlobDir, Tester } from "../utility/matcher";
import { getStat, getFiles, Stats } from "../utility/fs";
import { verbose, error } from "./logging";
import { FileList } from "./fileList";
import { File } from "./file";
import { cache, checkCache } from "./cache";
import { watcher } from "./watch";

/**
 * 获取全局匹配器。
 */
export var matcher = new Matcher;

/**
 * 当前待处理的文件列表。
 */
export var matchedFiles: string[] = [];

/**
 * 筛选指定的文件并返回一个文件列表。
 * @param patterns 用于筛选文件的通配符、正则表达式、函数或以上组合的数组。
 * @returns 返回一个文件列表对象。
 */
export function src(...patterns: Pattern[]) {
    // 遍历匹配 patterns 的文件要注意：
    // 1. 如果设置了 matchedFiles，则直接从 matchedFiles 找出匹配的文件。
    // 2. 应用全局的 matcher 配置。
    // 3. 监听模式下需要监听基路径。
    // 4. 此函数执行次数多，应保证较高的效率。
    // 5. patterns 可用于决定所有文件发布后的基路径。如 ["src/*.jpg", "src/*.png"] 的基路径是 "src"。

    const result = new FileList();
    const currentMatcher = new Matcher(patterns);
    const currentBase = currentMatcher.dir;

    // 如果只处理选中的文件，则只需筛选一遍文件。
    if (matchedFiles.length) {
        for (const name of matchedFiles) {
            if (currentMatcher.test(name) && matcher.test(name)) {
                result.add(new File(name, currentBase && name.startsWith(currentBase) ? name.substr(currentBase.length) : name));
            }
        }
        result.end();
    } else {

        type DoneCallback = (fileCache: null | boolean | string[]) => void;

        /**
         * 存储每个名称的信息以加速读取。
         * - true：当前名称是一个文件。
         * - false：当前名称是一个文件且已添加到结果。
         * - [字符串]：当前名称是一个文件夹，数组表示所有文件。
         * - [函数]：正在加载当前名称。
         */
        const fileCaches: { [name: string]: boolean | string[] | DoneCallback[]; } = { __proto__: null };

        // 等待所有模式查找完成后执行 result.end()。
        let waiting = currentMatcher.patterns.length;
        if (waiting) {
            const eachCallback = () => {
                if (--waiting > 0) return;
                result.end();
            };
            for (let i = 0; i < currentMatcher.patterns.length; i++) {
                const pattern = currentMatcher.patterns[i];

                /**
                 * 处理一个文件或文件夹。
                 */
                function process(name: string, pattern: { test: Tester }, callback: () => void) {

                    // 检查当前匹配器忽略。
                    if (currentMatcher.ignore(name)) {
                        verbose("Ignored: {path}", { path: name });
                        return callback();
                    }

                    // 检查全局忽略。
                    if (matcher.ignore(name)) {
                        verbose("Global Ignored: {path}", { path: name });
                        return callback();
                    }

                    function done(fileCache: null | boolean | string[]) {

                        // 出现错误或该路径已添加到结果。
                        if (!fileCache) {
                            return callback();
                        }

                        // 处理文件。
                        if (fileCache === true) {

                            // 检查当前匹配器筛选。
                            if (!pattern.test(name)) {
                                return callback();
                            }

                            // 检查全局全局筛选。
                            if (!matcher.match(name)) {
                                fileCaches[name] = false;
                                verbose("Global Filtered: {path}", { path: name });
                                return callback();
                            }

                            // 添加文件。
                            fileCaches[name] = false;
                            result.add(new File(name, currentBase && name.startsWith(currentBase) ? name.substr(currentBase.length) : name));
                            return callback();
                        }

                        // 处理文件夹。
                        let waiting = fileCache.length;
                        if (!waiting) {
                            return callback();
                        }
                        const eachCallback = () => {
                            if (--waiting > 0) return;
                            callback();
                        };
                        for (const file of fileCache) {
                            process(name ? name + "/" + file : file, pattern, eachCallback);
                        }

                    }

                    const fileCache = fileCaches[name];
                    if (fileCache) {

                        // 正在加载：加入回调列表。
                        if (Array.isArray(fileCache) && typeof fileCache[0] === "function") {
                            (<DoneCallback[]>fileCache).push(done);
                            return;
                        }

                        // 已加载：直接处理。
                        return done(<boolean | string[]>fileCache);
                    }

                    // 未加载。
                    fileCaches[name] = [done];
                    getStat(name || ".", (e, stats) => {
                        const fileCache = <DoneCallback[]>fileCaches[name];
                        if (e) {
                            error(e);
                            for (const func of fileCache) {
                                func(null);
                            }
                            return;
                        }
                        if (stats.isFile()) {
                            fileCaches[name] = true;

                            // 如果存在缓存则跳过此文件。
                            if (cache) {
                                return checkCache(name, result => {
                                    for (const func of fileCache) {
                                        func(result ? false : true);
                                    }
                                }, stats);
                            }

                            for (const func of fileCache) {
                                func(true);
                            }
                            return;
                        }
                        if (stats.isDirectory()) {
                            getFiles(name || ".", (e, entries) => {
                                if (e) {
                                    error(e);
                                    entries = [];
                                }
                                fileCaches[name] = entries;
                                for (const func of fileCache) {
                                    func(entries);
                                }
                            });
                        }
                    });
                }

                const base = pattern.glob ? getGlobDir(pattern.glob).slice(0, -1) : ".";
                process(base, pattern, eachCallback);
                if (watcher) watcher.add(base);
            }
        } else {
            result.end();
        }
    }
    return result;
}
