﻿import "source-map-support/register";
import * as assert from "assert";
import * as matcher from "../../lib/utility/matcher";

describe("matcher", () => {
    it('test', () => {
        assert.equal(new matcher.Matcher("abc").test("abc"), true);
        assert.equal(new matcher.Matcher("abc.js").test("abc"), false);
        assert.equal(new matcher.Matcher("abc/def").test("abc/d"), false);
        assert.equal(new matcher.Matcher("abc.js").test("abc.js"), true);
        assert.equal(new matcher.Matcher('path/to/*.js').test('path/to/a.js'), true);
        assert.equal(new matcher.Matcher('path/to/*.js').test('path/to/a.css'), false);
        assert.equal(new matcher.Matcher('path/to/*.js').test('path/to.js'), false);
        assert.equal(new matcher.Matcher('path/to/*.js').test('path/to/a/b.js'), false);
        assert.equal(new matcher.Matcher('/root/path/to/*.js').test('root/path/to/a.js'), true);
        assert.equal(new matcher.Matcher('/root/path/to/*.js').test('root/path/toa/a.js'), false);
        assert.equal(new matcher.Matcher('/*.js').test('a.js'), true);
        assert.equal(new matcher.Matcher('/*.js').test('a/b.js'), false);
        assert.equal(new matcher.Matcher('*.js').test('a.js'), true);
        assert.equal(new matcher.Matcher('*.js').test('b/a.js'), true);
        assert.equal(new matcher.Matcher('*.js').test('a/b/.js'), true);
        assert.equal(new matcher.Matcher('**/*.js').test('a/b/.js'), true);
        assert.equal(new matcher.Matcher('**/*.js').test('.js'), true);
        assert.equal(new matcher.Matcher('path/?').test('path/a'), true);
        assert.equal(new matcher.Matcher('path/?').test('path/ab'), false);
        assert.equal(new matcher.Matcher('path/[ab]').test('path/a'), true);
        assert.equal(new matcher.Matcher('path/[ab]').test('path/b'), true);
        assert.equal(new matcher.Matcher('path/[ab]').test('path/ab'), false);
        assert.equal(new matcher.Matcher('path/[^ab]').test('path/a'), false);
        assert.equal(new matcher.Matcher('path/[^ab]').test('path/b'), false);
        assert.equal(new matcher.Matcher('path/[^ab]').test('path/c'), true);
        assert.equal(new matcher.Matcher('path/*').test('path/'), true);
        assert.equal(new matcher.Matcher('path/abc*').test('path/abc'), true);
        assert.equal(new matcher.Matcher('path/abc*').test('path/abcd'), true);
        assert.equal(new matcher.Matcher('path/**/*').test('path/'), true);
        assert.equal(new matcher.Matcher('path/**/subdir/foo.*').test('path/subdir/foo.js'), true);
        assert.equal(new matcher.Matcher('path/**/subdir/foo.*').test('path/foo/subdir/foo.js'), true);
        assert.equal(new matcher.Matcher('path/**/subdir/foo.*').test('path/foo/subdir/foo1.js'), false);
        assert.equal(new matcher.Matcher('path/**/subdir/foo.*').test('path/foo/subdir/foo'), false);
        assert.equal(new matcher.Matcher('path/**/subdir/foo.*').test('path/foo/foo2/subdir/foo.txt'), true);
        assert.equal(new matcher.Matcher('path/**/subdir/foo.*').test('path/foo/foo2/subdir/foo'), false);
        assert.equal(new matcher.Matcher('./path/**/subdir/foo.*').test('path/foo/foo2/subdir/foo.txt'), true);
        assert.equal(new matcher.Matcher('./path/**/subdir/foo.*').test('path/foo/foo2/subdir/Foo.txt'), true);
        assert.equal(new matcher.Matcher('../path/**/subdir/foo.*').test('../path/foo/foo2/subdir/Foo.txt'), true);

        assert.equal(new matcher.Matcher(['../path/**/subdir/foo.*', "!foo.txt"]).test('../path/foo/foo2/subdir/Foo.txt'), false);
    });
    it("dir", () => {
        // assert.equal(new matcher.Matcher("abc").dir, ".");
        // assert.equal(new matcher.Matcher('path/to/*.js').dir, 'path/to/');
        // assert.equal(new matcher.Matcher('/root/path/to/*.js').dir, 'root/path/to/');
        // assert.equal(new matcher.Matcher('/*.js').dir, '.');
        // assert.equal(new matcher.Matcher('*.js').dir, '.');
        // assert.equal(new matcher.Matcher('**/*.js').dir, '.');
        // assert.equal(new matcher.Matcher('path/?').dir, 'path/');
        // assert.equal(new matcher.Matcher('path/abc[ab]').dir, 'path/');
        // assert.equal(new matcher.Matcher('path/*').dir, 'path/');
        // assert.equal(new matcher.Matcher('path/abc*').dir, 'path/');
        // assert.equal(new matcher.Matcher('path/**/*').dir, 'path/');
        // assert.equal(new matcher.Matcher('path/**/subdir/foo.*').dir, 'path');
        // assert.equal(new matcher.Matcher("abc/").dir, "abc/");
        // assert.equal(new matcher.Matcher(["abc/goo", "abc/foo"]).dir, "abc");
        // assert.equal(new matcher.Matcher(["abc/**/*.js", "abc/**/*.css"]).dir, "abc");
        // assert.equal(new matcher.Matcher(/a/).dir, "");
        // assert.equal(new matcher.Matcher(["abc/", "!abc/"]).dir, "abc/");
        // assert.equal(new matcher.Matcher(["../abc/**/*.js", "abc/**/*.css"]).dir, "..");
        // assert.equal(new matcher.Matcher(["../abc/**/*.js", /a/]).dir, "..");
    });
    it("getGlobBase", () => {
        assert.equal(matcher.getGlobDir("a/*.jpg"), "a/");
        assert.equal(matcher.getGlobDir("a/b/*.jpg"), "a/b/");
        assert.equal(matcher.getGlobDir("a"), "");
    });
    it("isGlob", () => {
        assert.equal(matcher.isGlob("a"), false);
        assert.equal(matcher.isGlob("a*"), true);
    });
});
