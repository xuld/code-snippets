﻿import "source-map-support/register";
import * as assert from "assert";
import * as path from "path";
import logging = require("../../lib/builder/logging");

describe("logging", () => {

    it("log", () => {
        const logs = [];
        logging.onLog = data => { logs.push(data); return false; };
        logging.log("data");
        assert.deepEqual(logs, ["data"]);
    });

    it("format", () => {
        assert.equal(logging.format("A"), "A");
    });

    it('getDisplayName', () => {
        logging.fullPath = false;
        assert.equal(logging.getDisplayName("a"), "a");
        assert.equal(logging.getDisplayName(path.resolve("cd.jpg")), "cd.jpg");

        logging.fullPath = true;
        assert.equal(logging.getDisplayName("a"), path.resolve("a"));
        assert.equal(logging.getDisplayName(process.cwd() + "/cd.jpg"), path.resolve("cd.jpg"));
        assert.equal(logging.getDisplayName("cd.jpg"), path.resolve("cd.jpg"));
    });

});
